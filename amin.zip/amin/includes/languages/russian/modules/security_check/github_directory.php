<?php
/*
  Copyright (c) 2019, G Burton
  All rights reserved. 

  Translation to RU from Fredi. Updated 7/01/2020
*/

define('MODULE_SECURITY_CHECK_GITHUB_TITLE', 'Директория Github');
define('MODULE_SECURITY_CHECK_GITHUB_DIRECTORY_EXISTS', 'Каталог Github существует по адресу: ' . DIR_FS_CATALOG . '.github. Вы должны удалить этот каталог.');
