cfg_ec_checkout_image_title = PayPal Express Checkout Button
cfg_ec_checkout_image_desc = Установите этот параметр в значение «Динамический», если кнопка «Экспресс-заказ» используется в кампании.

cfg_ec_checkout_image_dynamic = Dynamic.
cfg_ec_checkout_image_static = Static
