<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2016 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_PRODUCT_TITLE_TITLE', 'Заголовок товара');
  define('MODULE_HEADER_TAGS_PRODUCT_TITLE_DESCRIPTION', 'Добавьте заголовок (тайтл) этого товара');

  define('MODULE_HEADER_TAGS_PRODUCT_SEO_SEPARATOR', ' | ');
  