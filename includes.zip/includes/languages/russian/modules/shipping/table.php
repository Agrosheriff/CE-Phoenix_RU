<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2019 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

define('MODULE_SHIPPING_TABLE_TEXT_TITLE', 'Табличный тариф');
define('MODULE_SHIPPING_TABLE_TEXT_DESCRIPTION', 'Табличный тариф');
define('MODULE_SHIPPING_TABLE_TEXT_WAY', 'Оптимальный путь');
define('MODULE_SHIPPING_TABLE_TEXT_WEIGHT', 'Вес');
define('MODULE_SHIPPING_TABLE_TEXT_AMOUNT', 'Сумма ');
define('MODULE_SHIPPING_TABLE_SORT_ORDER', 'Сортировать ');
define('MODULE_SHIPPING_TABLE_TAX_CLASS', 'Налог ');
define('MODULE_SHIPPING_TABLE_STATUS', 'Статус ');
?>
