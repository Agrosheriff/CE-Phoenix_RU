<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

define('MODULE_SECURITY_CHECK_EXTENDED_EXT_DIRECTORY_LISTING_TITLE', 'ext/ Список директорий');
define('MODULE_SECURITY_CHECK_EXTENDED_EXT_DIRECTORY_LISTING_HTTP_200', 'The <a href="' . tep_catalog_href_link('ext/') . '" target="_blank">' . DIR_WS_CATALOG . 'ext/</a> каталог является общедоступным и/или доступен для просмотра - отключите directory listing для этого каталога в конфигурации вашего веб-сервера.');
?>
