<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2019 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_BREADCRUMB_SCHEMA_TITLE', 'Схема JSON-LD для Breadcrumb');
  define('MODULE_HEADER_TAGS_BREADCRUMB_SCHEMA_DESCRIPTION', 'Добавить Breadcrumb Schema JSON-LD для всех страниц.');
  