<?php
/*
$Id$
osCommerce, Open Source E-Commerce Solutions
http://www.oscommerce.com
Copyright (c) 2020 osCommerce
Translation to RU from Fredi. Updated 7/01/2020
Released under the GNU General Public License
*/

define('MODULE_CONTENT_TEXT_MAIN_TITLE', 'Основной текст');
define('MODULE_CONTENT_TEXT_MAIN_DESCRIPTION', 'Показать модуль "Основной текст" на главной стр.');

define('MODULE_CONTENT_TEXT_MAIN_TEXT', '');