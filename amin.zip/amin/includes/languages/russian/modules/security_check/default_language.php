<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

define('ERROR_NO_DEFAULT_LANGUAGE_DEFINED', 'ОШИБКА: Нет языка по умолчанию. Установите его: Админ Инструменты->Местонахождение->Языки');
?>
