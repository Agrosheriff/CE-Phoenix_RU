<?php
/*
$Id$
osCommerce, Open Source E-Commerce Solutions
http://www.oscommerce.com
Copyright (c) 2020 osCommerce
Translation to RU from Fredi. Updated 7/01/2020
Released under the GNU General Public License
*/

define('MODULE_NAVBAR_HOME_TITLE', 'Главная');
define('MODULE_NAVBAR_HOME_DESCRIPTION', 'Показать ссылку на Главную страницу в Панели навигации. <div class="secWarning">Если вы хотите иметь кнопку Главная постоянно отображаемой (даже тогда, когда остальная часть меню свернута, например, в CSS видового экрана) вы могли бы использовать модуль вместо Бренд Вашей фирмы.</div>');

define('MODULE_NAVBAR_HOME_PUBLIC_TEXT', '<i title="Главная" class="fas fa-home"></i><span class="d-inline d-sm-none d-md-inline"> Главная</span>');

