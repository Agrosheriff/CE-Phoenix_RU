<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2016 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

  const MODULE_CONTENT_CATEGORY_IMAGES_TITLE        = 'Картинки категорий';
  const MODULE_CONTENT_CATEGORY_IMAGES_DESCRIPTION  = 'Показать "Картинки категорий" на главной странице.';  
  const MODULE_CONTENT_CATEGORY_IMAGES_HEADING      = 'ТОВАРЫ ПО КАТЕГОРИЯМ'; 
  const MODULE_CONTENT_CATEGORY_IMAGES_SEE_MORE     = '(посмотреть больше)';
  