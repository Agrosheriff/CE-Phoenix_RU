<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2019 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

  define('MODULE_BOXES_REVIEWS_TITLE', 'Отзывы');
  define('MODULE_BOXES_REVIEWS_DESCRIPTION', 'Показать отзывы о товарах');
  
  define('MODULE_BOXES_REVIEWS_BOX_TITLE', 'Отзывы');

