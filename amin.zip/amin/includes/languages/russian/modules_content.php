<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2019 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Модули Контента');

define('TABLE_HEADING_MODULES', 'Модули');
define('TABLE_HEADING_GROUP', 'Группа');
define('TABLE_HEADING_SORT_ORDER', 'Сортировка');
define('TABLE_HEADING_MODULE_ACTIVE', 'Активен');
define('TABLE_HEADING_ACTION', 'Действие');

define('TEXT_INFO_VERSION', 'Версия:');
define('TEXT_INFO_ONLINE_STATUS', 'статус в сети');
define('TEXT_INFO_API_VERSION', 'API версия:');

define('TEXT_MODULE_DIRECTORY', 'Директория модулей:');
