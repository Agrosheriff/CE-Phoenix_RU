cfg_ps_ewp_public_cert_id_title = Your PayPal Public Certificate ID
cfg_ps_ewp_public_cert_id_desc = The Certificate ID assigned to your certificate shown in your PayPal Encrypted Payment Settings Profile page.
