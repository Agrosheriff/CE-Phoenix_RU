<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2018 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_CREATE_ACCOUNT_LINK_TITLE', 'Создание профиля');
  define('MODULE_CONTENT_CREATE_ACCOUNT_LINK_DESCRIPTION', 'Показать контейнер на создание профиля на странице входа');

  define('MODULE_CONTENT_LOGIN_HEADING_NEW_CUSTOMER', 'Новый клиент');
  define('MODULE_CONTENT_LOGIN_TEXT_NEW_CUSTOMER', 'Я новый клиент.');
  define('MODULE_CONTENT_LOGIN_TEXT_NEW_CUSTOMER_INTRODUCTION', 'Создав профиль в '. STORE_NAME. ' вы сможете делать покупки быстрее, быть в курсе состояния заказов и отслеживать заказы, которые вы делали ранее.');
