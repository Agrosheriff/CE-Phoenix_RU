<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_ORDER_TOTAL_SHIPPING_TITLE', 'Доставка');
  define('MODULE_ORDER_TOTAL_SHIPPING_DESCRIPTION', 'Стоимость доставки');

  define('FREE_SHIPPING_TITLE', 'Бесплатная доставка');
  define('FREE_SHIPPING_DESCRIPTION', 'Бесплатная доставка для заказов свыше %s');
?>