<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_DATEPICKER_JQUERY_TITLE', 'Выбор даты jQuery');
  define('MODULE_HEADER_TAGS_DATEPICKER_JQUERY_DESCRIPTION', 'Добавить Выбор даты jQuery на специфические страницы');
?>
