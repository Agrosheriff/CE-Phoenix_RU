<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
  JcM Terms V1.0 16-01-2020. Ru translated Fred.
*/

const CHECKBOX_TEXT  = 'Пожалуйста, прочитайте, нажмите кнопку справа, чтобы принять условия и продолжить.';
const BUTTON_TEXT    =  'Наша политика конфиденциальности';
const TERMS_TITLE    =  'Наша политика конфиденциальности';
const TERMS_TEXT     = 'Мы гарантируем секретность всей конфиденциальной информации поступающей от клиентов. Мы так же гарантируем, что эта информация не будет доступна или передана кому либо другому, включая частных лиц и организации. <br /><a href="/privacy.php" target="_blank">Читать полную политику конфиденциальности</a>';