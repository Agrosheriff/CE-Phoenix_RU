<?php
/*
$Id$
osCommerce, Open Source E-Commerce Solutions
http://www.oscommerce.com
Copyright (c) 2020 osCommerce
Translation to RU from Fredi. Updated 7/01/2020
Released under the GNU General Public License
*/

const MODULE_CONTENT_PINF_MESSAGE_TITLE = 'Сообщение о том, что товара нет в наличии';
const MODULE_CONTENT_PINF_MESSAGE_DESCRIPTION = 'Показать сообщение на product_info Page что товара нет в наличии.';

const MODULE_CONTENT_PINF_MESSAGE_PRODUCT_NOT_FOUND = 'Этого товара сейчас нет на нашем складе. Мы ожидаем его поступление на склад в ближайшие дни.';

