<?php
/*
  $Id $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com
  Translation to RU from Fredi. Updated 7/01/2020
  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Выход');
define('NAVBAR_TITLE', 'Выход');
define('TEXT_MAIN', 'Вы успешно вышли.<br>Содержимое Вашей корзины сохранено, Вы можете вернуться и оформить Ваши покупки позже.<br>Возвращайтесь поскорее, наши товары это то, что Вы искали и они вас ждут!'); 
?>
