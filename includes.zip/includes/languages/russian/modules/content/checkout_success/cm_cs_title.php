<?php
/*
$Id$
osCommerce, Open Source E-Commerce Solutions
http://www.oscommerce.com
Copyright (c) 2020 osCommerce
Translation to RU from Fredi. Updated 7/01/2020
Released under the GNU General Public License
*/

define('MODULE_CONTENT_CHECKOUT_SUCCESS_TITLE_TITLE', 'Заголовок');
define('MODULE_CONTENT_CHECKOUT_SUCCESS_TITLE_DESCRIPTION', 'Показывает заголовок страницы.');
define('MODULE_CONTENT_CHECKOUT_SUCCESS_TITLE_PUBLIC_TITLE', 'Ваш заказ обработан');
