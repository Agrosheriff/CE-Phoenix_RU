<?php
/*
$Id$
osCommerce, Open Source E-Commerce Solutions
http://www.oscommerce.com
Copyright (c) 2020 osCommerce
Translation to RU from Fredi. Updated 7/01/2020
Released under the GNU General Public License
*/

const MODULE_CONTENT_PI_OA_TITLE       = 'Опции и атрибуты';
const MODULE_CONTENT_PI_OA_DESCRIPTION = 'Показать Опции и атрибуты товара на странице product_info.';

const MODULE_CONTENT_PI_OA_HEADING_TITLE = 'Опции и атрибуты товара:';

const MODULE_CONTENT_PI_OA_ENFORCE_SELECTION = '--- Выберите опцию ---';
