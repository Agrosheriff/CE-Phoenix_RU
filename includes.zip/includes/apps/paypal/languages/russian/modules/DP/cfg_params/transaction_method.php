cfg_dp_transaction_method_title = Метод транзакции
cfg_dp_transaction_method_desc = Установите на продажи, чтобы немедленно захватить средства для каждого сделанного заказа.

cfg_dp_transaction_method_authorize = Авторизация
cfg_dp_transaction_method_sale = Продажа
