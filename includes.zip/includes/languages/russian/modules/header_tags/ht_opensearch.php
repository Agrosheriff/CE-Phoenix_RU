<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2019 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_OPENSEARCH_TITLE', 'Свободный поиск OpenSearch');
  define('MODULE_HEADER_TAGS_OPENSEARCH_DESCRIPTION', 'Разрешить браузеру искать в магазине через Свободный поиск');
?>
