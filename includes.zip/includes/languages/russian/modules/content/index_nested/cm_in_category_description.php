<?php
/*
  $Id:

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2016 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_IN_CATEGORY_DESCRIPTION_TITLE', 'Описание категорий');
  define('MODULE_CONTENT_IN_CATEGORY_DESCRIPTION_DESCRIPTION', 'Показать Описание категорий на index.php');
  