<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2019 osCommerce
  Translation to RU from Fredi. Updated 17/01/2020
  Released under the GNU General Public License
*/


define('MODULE_CONTENT_PI_REVIEW_STARS_TITLE', 'Ссылка / Обзор Звезд');
define('MODULE_CONTENT_PI_REVIEW_STARS_DESCRIPTION', 'Показать звезды, количество отзывов и ссылку для написания отзыва на странице product_info');

define('MODULE_CONTENT_PI_REVIEW_STARS_COUNT', '%s Отзывы');
define('MODULE_CONTENT_PI_REVIEW_STARS_COUNT_ONE', '%s Отзывы');

define('MODULE_CONTENT_PI_REVIEW_STARS_DO_REVIEW', 'Добвавить Ваш Отзыв');

define('MODULE_CONTENT_PI_REVIEW_STARS_DO_FIRST_REVIEW', 'Будьте первым кто оценит этот продукт');
