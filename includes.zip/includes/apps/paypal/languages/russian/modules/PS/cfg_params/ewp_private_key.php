cfg_ps_ewp_private_key_title = Ваш Private Key
cfg_ps_ewp_private_key_desc = Местоположение и имя вашего закрытого ключа для шифрования параметров. (* .pem)
