cfg_dp_cards_title = Cards
cfg_dp_cards_desc = Select the card types to allow payments from.
