cfg_gateway_title = Gateway Шлюз
cfg_gateway_desc = Установите шлюз, который будет использоваться для обработки платежей.

cfg_gateway_paypal = PayPal
cfg_gateway_payflow = Payflow
