<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2019 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Напишите письмо в отдел обслуживания магазина:');
define('NAVBAR_TITLE', 'Напишите нам пожалуйста ваше сообщение ');
define('TEXT_SUCCESS', 'Ваше сообщение было успешно отправлено в отдел обслуживания <strong>' . STORE_NAME . '</strong>.');
define('EMAIL_SUBJECT', 'Сообщение от  %s');

define('ENTRY_NAME', 'Ваше имя:');
define('ENTRY_NAME_TEXT', '');
define('ENTRY_EMAIL', 'E-Mail адрес:');
define('ENTRY_EMAIL_TEXT', '');
define('ENTRY_ENQUIRY', 'Сообщение или запрос:');
define('ENTRY_ENQUIRY_TEXT', '');

define('ERROR_ACTION_RECORDER', 'Внимание, произошла ошибка: Ваше сообщение не было отправлено. Попробуйте повторить через %s минут.');
