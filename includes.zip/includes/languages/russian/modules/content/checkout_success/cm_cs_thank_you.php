<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_CHECKOUT_SUCCESS_THANK_YOU_TITLE', 'Спасибо! Мы ждем Вас снова!');
  define('MODULE_CONTENT_CHECKOUT_SUCCESS_THANK_YOU_DESCRIPTION', 'Показывать блок благодарности на странице успешного оформления заказа.');

  define('MODULE_CONTENT_CHECKOUT_SUCCESS_TEXT_SUCCESS', 'Поздравляем, Ваш Заказ успешно оформлен! В ближайшее время с Вами свяжется наш менеджер, для согласования всех деталей по Вашему заказу.');
  define('MODULE_CONTENT_CHECKOUT_SUCCESS_TEXT_SEE_ORDERS', 'Вы можете контролировать, как изменяется статус Вашего заказа в процессе его обработки в Вашем персональном Кабинете на странице:  <a href="%s">История заказов</a>');
  define('MODULE_CONTENT_CHECKOUT_SUCCESS_TEXT_CONTACT_STORE_OWNER', 'Свяжитесь пожалуйста с нашей администрацией если у Вас есть вопросы, замечания или предложения, через страницу: <a href="%s">Контакты</a>.');
  define('MODULE_CONTENT_CHECKOUT_SUCCESS_TEXT_THANKS_FOR_SHOPPING', 'Спасибо за покупки! Спасибо Вам, что посетили наш магазин и нашли то, что искали!');
?>
