<?php
/*
$Id$
osCommerce, Open Source E-Commerce Solutions
http://www.oscommerce.com
Copyright (c) 2020 osCommerce
Translation to RU from Fredi. Updated 7/01/2020
Released under the GNU General Public License
*/

  define('MODULE_NAVBAR_BRAND_TITLE', 'Бренд Вашей фирмы');
  define('MODULE_NAVBAR_BRAND_DESCRIPTION', 'Показать Бренд Вашей фирмы в панели навигации.  <div class="secWarning">Это может быть простая ссылка или что-то более сложное, например - изображение. <br> <br> Для получения более подробной информации об использовании изображения см <a target="_blank" href="https://getbootstrap.com/docs/4.1/components/navbar/#brand"><u>navbar/#brand</u></a></div>');

  define('MODULE_NAVBAR_BRAND_PUBLIC_TEXT', STORE_NAME);

