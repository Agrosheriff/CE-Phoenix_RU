<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2019 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_CANONICAL_TITLE', 'Канонические линки');
  define('MODULE_HEADER_TAGS_CANONICAL_DESCRIPTION', 'добавить Канонические линки в category/product pages.  <div class="secWarning">Обратите внимание, что атрибуты hreflang не поддерживаются в этом модуле, что повлияет на вас, если в вашем магазине более одного языка.<br><br>Вам следует обратиться за советом к хорошему консультанту по SEO. (eg Jack_mcs in the main osCommerce forum).</div>');
  