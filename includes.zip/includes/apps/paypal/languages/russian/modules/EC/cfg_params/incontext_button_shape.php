cfg_ec_incontext_button_shape_title = Форма кнопки
cfg_ec_incontext_button_shape_desc = Форма Checkout с кнопкой PayPal.

cfg_ec_incontext_button_shape_pill = Овал
cfg_ec_incontext_button_shape_rect = Прямоугольник
