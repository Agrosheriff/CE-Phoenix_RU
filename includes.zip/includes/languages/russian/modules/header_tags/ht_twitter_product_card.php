<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2015 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_TWITTER_PRODUCT_CARD_TITLE', 'Twitter Корзина');
  define('MODULE_HEADER_TAGS_TWITTER_PRODUCT_CARD_DESCRIPTION', 'Добавить Twitter Card tags на ваши страницы информации о продуктах.');
  