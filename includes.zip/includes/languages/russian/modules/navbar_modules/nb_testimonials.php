<?php
/*
$Id$
osCommerce, Open Source E-Commerce Solutions
http://www.oscommerce.com
Copyright (c) 2020 osCommerce
Translation to RU from Fredi. Updated 7/01/2020
Released under the GNU General Public License
*/

  define('MODULE_NAVBAR_TESTIMONIALS_TITLE', 'Рекомендации'); 
  define('MODULE_NAVBAR_TESTIMONIALS_DESCRIPTION', 'Показать Рекомендации в Панели навигации.');

  define('MODULE_NAVBAR_TESTIMONIALS_PUBLIC_TEXT', '<i title="Рекомендации" class="fas fa-fw fa-user-edit"></i><span class="d-inline d-sm-none d-md-inline"> Рекомендации</span>');

