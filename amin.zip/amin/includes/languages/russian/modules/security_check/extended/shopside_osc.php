<?php
/*
  Copyright (c) 2019, G Burton
  All rights reserved. 

  Translation to RU from Fredi. Updated 7/01/2020
*/

define('MODULE_SECURITY_CHECK_EXTENDED_SHOPSIDE_OSC_TITLE', 'Версия - OSCOM CE Phoenix');
define('MODULE_SECURITY_CHECK_EXTENDED_SHOPSIDE_OSC_MESSAGE', 'Ваш магазин на базе OSCOM CE Phoenix v%s, смотри <a href="' . tep_href_link('version_check.php') . '"><u>Инструменты > Проверка версии</u></a> для подробной информации.');

