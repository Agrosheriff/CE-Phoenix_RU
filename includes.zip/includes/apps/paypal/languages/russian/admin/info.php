online_documentation_title = Интернет документация

online_documentation_body = <p>Интернет документация доступна на сайте osCommerce Library website:</p>
<p>:button_online_documentation</p>

button_online_documentation = Интернет документация

online_forum_title = Интернет форум

online_forum_body = <p>Поддержка запросов может быть размещена на osCommerce Support Forum PayPal Channel:</p>
<p>:button_online_forum</p>

button_online_forum = osCommerce форум поддержки
