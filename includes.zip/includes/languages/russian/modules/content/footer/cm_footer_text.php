<?php
/*
$Id$
osCommerce, Open Source E-Commerce Solutions
http://www.oscommerce.com
Copyright (c) 2020 osCommerce
Translation to RU from Fredi. Updated 7/01/2020
Released under the GNU General Public License
*/

define('MODULE_CONTENT_FOOTER_TEXT_TITLE', 'Текстовый блок');
define('MODULE_CONTENT_FOOTER_TEXT_DESCRIPTION', 'Добавить Текстовый блок в футер');

define('MODULE_CONTENT_FOOTER_TEXT_HEADING_TITLE', 'О нас');


define('MODULE_CONTENT_FOOTER_TEXT_TEXT', '<p>--- Введите необходимый вам текст.</p>');

