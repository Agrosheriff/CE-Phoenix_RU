<?php
/*
  $Id$

  Copyright (c) 2016:
    Dan Cole - @Dan Cole
    James Keebaugh - @kymation
    Lambros - @Tsimi
    Rainer Schmied - @raiwa

  Translation to RU from Fredi. Updated 7/01/2020
*/

  define('MODULE_CONTENT_SC_ORDER_SUBTOTAL_TITLE', 'Стоимость товара в Корзине');
  define('MODULE_CONTENT_SC_ORDER_SUBTOTAL_DESCRIPTION', 'Показать Стоимость товара в Корзине на странице Корзины');
  
  define('MODULE_CONTENT_SC_ORDER_SUBTOTAL_SUB_TOTAL', 'Стоимость товара в Корзине: <span class="cart-subtotal">%s</span>');
