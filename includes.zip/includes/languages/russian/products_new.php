<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com
  Translation to RU from Fredi. Updated 7/01/2020
  Copyright (c) 2019 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Новые товары');
define('HEADING_TITLE', 'Новые товары');

define('TEXT_MANUFACTURER', 'Производитель:');
define('TEXT_PRICE', 'Стоимость товара ');

define('TEXT_NO_PRODUCTS', 'Нет новинок для показа.');

