<?php
/*
  Copyright (c) 2018, G Burton
  All rights reserved. 

  Translation to RU from Fredi. Updated 7/01/2020
*/

define('MODULE_CFG_MODULE_CURRENCIES_TITLE', 'Обновить валюты');

