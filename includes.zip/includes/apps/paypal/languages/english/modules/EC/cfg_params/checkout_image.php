cfg_ec_checkout_image_title = PayPal Express Checkout Button
cfg_ec_checkout_image_desc = Set this to Dynamic if the Express Checkout button is used with a campaign.

cfg_ec_checkout_image_dynamic = Dynamic
cfg_ec_checkout_image_static = Static
