<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2019 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_CHECKOUT_SUCCESS_DOWNLOADS_TITLE', 'Выполнить загрузку');
  define('MODULE_CONTENT_CHECKOUT_SUCCESS_DOWNLOADS_DESCRIPTION', 'Показывать ссылку для скачивания на странице успешного оформления заказа');

  define('TABLE_HEADING_DOWNLOAD_DATE', 'Действительна до: ');
  define('TABLE_HEADING_DOWNLOAD_COUNT', ' осталось скачиваний ');
  define('HEADING_DOWNLOAD', 'Выполнить загрузку:');
  define('FOOTER_DOWNLOAD', 'Вы можете Выполнить загрузку \'%s\'');
