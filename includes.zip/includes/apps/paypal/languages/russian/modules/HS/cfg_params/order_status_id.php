cfg_hs_order_status_id_title = Статус заказа
cfg_hs_order_status_id_desc = Установите этот статус заказов, который присваивается новым заказам.

cfg_hs_order_status_id_default = -- Сохранить установки по умолчанию --
