cfg_hs_transaction_method_title = Метод оплаты
cfg_hs_transaction_method_desc = Установите на Sale, чтобы немедленно захватить средства для каждого сделанного заказа.

cfg_hs_transaction_method_authorize = Авторизация
cfg_hs_transaction_method_sale = Sale
