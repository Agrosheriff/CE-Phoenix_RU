<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2016 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_MANUFACTURERS_SEO_TITLE', 'Производитель SEO');
  define('MODULE_HEADER_TAGS_MANUFACTURERS_SEO_DESCRIPTION', 'Добавить Производитель SEO элементы, которые  вы определили для производителя, к базовому коду страницы производителя (так называемый мета-описания и мета ключевые слова). Хорошо подходит для SEO.');
  