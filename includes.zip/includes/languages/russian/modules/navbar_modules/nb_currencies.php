<?php
/*
$Id$
osCommerce, Open Source E-Commerce Solutions
http://www.oscommerce.com
Copyright (c) 2020 osCommerce
Translation to RU from Fredi. Updated 7/01/2020
Released under the GNU General Public License
*/

define('MODULE_NAVBAR_CURRENCIES_TITLE', 'Валюты');
define('MODULE_NAVBAR_CURRENCIES_DESCRIPTION', 'Показать валюты в Панели навигации. <div class="secWarning">Если у вас есть только одна валюта в вашем магазине, нет никакого смысла установки этого модуля.</div>');

define('MODULE_NAVBAR_CURRENCIES_SELECTED_CURRENCY', '<i title="Выбрать валюту: %1$s" class="fas fa-comments-dollar"></i><span class="d-inline d-sm-none d-md-inline"> %1$s</span> <span class="caret"></span>');
