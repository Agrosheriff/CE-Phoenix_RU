<?php
/*
$Id$
osCommerce, Open Source E-Commerce Solutions
http://www.oscommerce.com
Copyright (c) 2020 osCommerce
Translation to RU from Fredi. Updated 7/01/2020
Released under the GNU General Public License
*/

const MODULE_CONTENT_PI_NAME_TITLE = 'Название товара';
const MODULE_CONTENT_PI_NAME_DESCRIPTION = 'Показать: Название товара на странице товара.';

const MODULE_CONTENT_PI_NAME_DISPLAY_NAME = '%s';

