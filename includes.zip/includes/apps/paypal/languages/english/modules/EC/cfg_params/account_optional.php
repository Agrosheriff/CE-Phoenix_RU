cfg_ec_account_optional_title = PayPal Account Optional
cfg_ec_account_optional_desc = Set this to True to allow customers to purchase through PayPal without requiring a PayPal account.

cfg_ec_account_optional_true = True
cfg_ec_account_optional_false = False
