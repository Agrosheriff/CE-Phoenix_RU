table_heading_action = Action
table_heading_ip = IP
table_heading_customer = Customer
table_heading_date = Date

guest = Guest

no_entries = No log entries found.

listing_number_of_log_entries = Displaying <strong>%d</strong> to <strong>%d</strong> (of <strong>%d</strong> entries)

dialog_delete_title = Delete All Log Entries?
dialog_delete_body = Are you sure you want to delete all log entries?

table_heading_entries_request = Request
table_heading_entries_response = Response

alert_delete_success = Log entries have been successfully deleted.
