<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_SOCIAL_BOOKMARKS_TWITTER_BUTTON_TITLE', 'Твиттер');
  define('MODULE_SOCIAL_BOOKMARKS_TWITTER_BUTTON_DESCRIPTION', 'Поделиться хорошим товаром. Сохранить в Твиттере.');
  define('MODULE_SOCIAL_BOOKMARKS_TWITTER_BUTTON_PUBLIC_TITLE', 'Твиттер');
?>
