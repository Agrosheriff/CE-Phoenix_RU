cfg_login_sort_order_title = Sort Order
cfg_login_sort_order_desc = Sort order of display. Lowest is displayed first.
