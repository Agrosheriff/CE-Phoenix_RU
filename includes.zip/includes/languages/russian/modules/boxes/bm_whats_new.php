<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2018 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

  define('MODULE_BOXES_WHATS_NEW_TITLE', 'Что новенького?');
  define('MODULE_BOXES_WHATS_NEW_DESCRIPTION', 'Показать новые товары');
  
  define('MODULE_BOXES_WHATS_NEW_BOX_TITLE', '<a href="%s">Что новенького?</a>');
