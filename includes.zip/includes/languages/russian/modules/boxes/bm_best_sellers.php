<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2018 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_BEST_SELLERS_TITLE', 'Популярное');
  define('MODULE_BOXES_BEST_SELLERS_DESCRIPTION', 'Показывать best sellers в global и category ');
  define('MODULE_BOXES_BEST_SELLERS_BOX_TITLE', 'Популярное');
