<?php
/*
$Id$
osCommerce, Open Source E-Commerce Solutions
http://www.oscommerce.com
Copyright (c) 2020 osCommerce
Translation to RU from Fredi. Updated 7/01/2020
Released under the GNU General Public License
*/

define('MODULE_CONTENT_FOOTER_EXTRA_COPYRIGHT_TITLE', 'Сведения об авторских правах');
define('MODULE_CONTENT_FOOTER_EXTRA_COPYRIGHT_DESCRIPTION', 'Добавить блок Копирайт в подвал сайта');

define('FOOTER_TEXT_BODY', '<p>Copyright &copy; ' . date('Y') . ' <a class="text-light" href="' . tep_href_link('index.php') . '">' . STORE_NAME . '</a> &middot; Powered by <a class="text-light" href="http://www.oscommerce.com" target="_blank">OSCOM CE Phoenix</a></p>');

