<?php
/*
$Id$
osCommerce, Open Source E-Commerce Solutions
http://www.oscommerce.com
Copyright (c) 2020 osCommerce
Translation to RU from Fredi. Updated 7/01/2020
Released under the GNU General Public License
*/

  define('MODULE_CONTENT_FOOTER_INFORMATION_TITLE', 'Блок информационных ссылок');
  define('MODULE_CONTENT_FOOTER_INFORMATION_DESCRIPTION', 'Добавить блок информационных ссылок в футер сайта');

  define('MODULE_CONTENT_FOOTER_INFORMATION_HEADING_TITLE', 'Информация');
      define('MODULE_CONTENT_FOOTER_INFORMATION_FAQ', 'FAQ Вопросы и ответы');

  const MODULE_CONTENT_FOOTER_INFORMATION_DATA = array(
    'privacy.php' => 'Безопасность и использование Cookie',
    'conditions.php' => 'Условия использования',
    'shipping.php' => 'Доставка и возврат',
    'contact_us.php' => 'Связаться с нами');
