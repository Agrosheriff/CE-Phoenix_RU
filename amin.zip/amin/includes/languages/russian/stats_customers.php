<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Лучшие покупатели по общей сумме заказов');

define('TABLE_HEADING_NUMBER', '№.');
define('TABLE_HEADING_CUSTOMERS', 'Покупатели');
define('TABLE_HEADING_TOTAL_PURCHASED', 'Общая сумма заказов');
?>