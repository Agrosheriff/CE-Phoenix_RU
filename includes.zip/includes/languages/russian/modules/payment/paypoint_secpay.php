<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_PAYPOINT_SECPAY_TEXT_TITLE', 'PayPoint.net SECPay');
  define('MODULE_PAYMENT_PAYPOINT_SECPAY_TEXT_PUBLIC_TITLE', 'Кредитная карта');
  define('MODULE_PAYMENT_PAYPOINT_SECPAY_TEXT_DESCRIPTION', 'Кредитная карта информация для тестирования:<br /><br />CC#: 4444333322221111<br />Действительна: Дата любая');
  define('MODULE_PAYMENT_PAYPOINT_SECPAY_TEXT_ERROR', 'Кредитная карта. ОШИБКА!');
  define('MODULE_PAYMENT_PAYPOINT_SECPAY_TEXT_ERROR_MESSAGE', 'Во время обработки платежа произошла ошибка. Попробуйте еще раз.');
  define('MODULE_PAYMENT_PAYPOINT_SECPAY_TEXT_ERROR_MESSAGE_N', 'Трансакция не подтверждена. Попробуйте другую карточку.');
  define('MODULE_PAYMENT_PAYPOINT_SECPAY_TEXT_ERROR_MESSAGE_C', 'Есть проблема со связьюс банком, попробуйте еще раз.');
?>
