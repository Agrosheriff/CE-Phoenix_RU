<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2018 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

  define('MODULE_BOXES_CURRENCIES_TITLE', 'Валюты');
  define('MODULE_BOXES_CURRENCIES_DESCRIPTION', 'Показывать выбор валют');
  define('MODULE_BOXES_CURRENCIES_BOX_TITLE', 'Валюта');
