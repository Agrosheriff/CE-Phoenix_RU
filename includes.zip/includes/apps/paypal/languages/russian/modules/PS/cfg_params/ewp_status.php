cfg_ps_ewp_status_title = Шифрование Website Payments
cfg_ps_ewp_status_desc = Установите для этого значение «Вкл.», чтобы зашифровать параметры транзакции, отправленные в PayPal с помощью вашего личного ключа и сертификата.

cfg_ps_ewp_status_true = Вкл.
cfg_ps_ewp_status_false = Откл.
