<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2018 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_REVIEWS_TITLE', 'Отзывы');
  define('MODULE_BOXES_REVIEWS_DESCRIPTION', 'Показать отзывы о продуктах');
  
  define('MODULE_BOXES_REVIEWS_BOX_TITLE', 'Отзывы');
  define('MODULE_BOXES_REVIEWS_BOX_WRITE_REVIEW', 'Напишите ваш отзыв о этом продукте!');
  define('MODULE_BOXES_REVIEWS_BOX_NO_REVIEWS', 'Еще нет отзывов о продукте');
  define('MODULE_BOXES_REVIEWS_BOX_TEXT_OF_5_STARS', '%s 5 звезд!');
