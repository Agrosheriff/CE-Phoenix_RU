<?php
/*
$Id$
osCommerce, Open Source E-Commerce Solutions
http://www.oscommerce.com
Copyright (c) 2020 osCommerce
Translation to RU from Fredi. Updated 7/01/2020
Released under the GNU General Public License
*/

define('MODULE_CONTENT_I_TITLE_TITLE', 'Заголовок страницы');
define('MODULE_CONTENT_I_TITLE_DESCRIPTION', 'Показать Заголовок страницы.');

define('MODULE_CONTENT_I_TITLE_PUBLIC_TITLE', 'Добро пожаловать в %s');

