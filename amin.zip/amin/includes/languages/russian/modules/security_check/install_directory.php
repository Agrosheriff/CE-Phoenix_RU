<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2019 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

define('WARNING_INSTALL_DIRECTORY_EXISTS', 'Папка установки этого магазина: ' . DIR_FS_CATALOG . 'install. Удалите ее для безопасности Вашего сайта.');
?>
