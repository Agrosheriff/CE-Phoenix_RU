cfg_ps_pdt_identity_token_title = PDT Identity Token
cfg_ps_pdt_identity_token_desc = Your Payment Data Transfer (PDT) Identity Token. This is shown on your PayPal Account Website Payment Preferences page and is used to verify transactions with.
