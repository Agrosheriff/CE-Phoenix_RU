<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2016 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_CATEGORY_TITLE_TITLE', 'Категории');
  define('MODULE_HEADER_TAGS_CATEGORY_TITLE_DESCRIPTION', 'Добавить заголовок категории на страницу');

  define('MODULE_HEADER_TAGS_CATEGORY_SEO_SEPARATOR', ' | ');
  