cfg_login_sandbox_secret_title = Test Secret
cfg_login_sandbox_secret_desc = The Secret of the PayPal REST App Test Credentials.
