<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2019 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_VERSION_CHECK_TITLE', 'Проверка версии');
define('MODULE_ADMIN_DASHBOARD_VERSION_CHECK_DESCRIPTION', 'Показать результат');
define('MODULE_ADMIN_DASHBOARD_VERSION_CHECK_DATE', 'Последняя проверка');
define('MODULE_ADMIN_DASHBOARD_VERSION_CHECK_CHECK_NOW', 'Проверить снова');
define('MODULE_ADMIN_DASHBOARD_VERSION_CHECK_NEVER', 'Никогда');

define('MODULE_ADMIN_DASHBOARD_VERSION_CHECK_UPDATE_AVAILABLE', '<i class="fas fa-exclamation-circle"></i>Имеются Обновления для OSCOM CE Phoenix!');
