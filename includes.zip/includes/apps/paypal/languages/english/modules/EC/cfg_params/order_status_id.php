cfg_ec_order_status_id_title = Order Status
cfg_ec_order_status_id_desc = Set this to the order status level that is assigned to new orders.

cfg_ec_order_status_id_default = -- Store Default Order Status --
