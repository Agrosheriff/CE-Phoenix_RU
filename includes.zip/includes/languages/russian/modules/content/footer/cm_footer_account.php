<?php
/*
$Id$
osCommerce, Open Source E-Commerce Solutions
http://www.oscommerce.com
Copyright (c) 2020 osCommerce
Translation to RU from Fredi. Updated 7/01/2020
Released under the GNU General Public License
*/

  define('MODULE_CONTENT_FOOTER_ACCOUNT_TITLE', 'Блок аккаунта');
  define('MODULE_CONTENT_FOOTER_ACCOUNT_DESCRIPTION', 'Добавить блок аккаунта в футер');

  define('MODULE_CONTENT_FOOTER_ACCOUNT_HEADING_TITLE', 'Мой кабинет');

  define('MODULE_CONTENT_FOOTER_ACCOUNT_BOX_ACCOUNT', 'Мой аккаунт');
  define('MODULE_CONTENT_FOOTER_ACCOUNT_BOX_ADDRESS_BOOK', 'Моя адресная книга');
  define('MODULE_CONTENT_FOOTER_ACCOUNT_BOX_ORDER_HISTORY', 'Моя история заказов');
  define('MODULE_CONTENT_FOOTER_ACCOUNT_BOX_LOGOFF', 'Безопасный выход');
  define('MODULE_CONTENT_FOOTER_ACCOUNT_BOX_CREATE_ACCOUNT', 'Создать аккаунт');
  define('MODULE_CONTENT_FOOTER_ACCOUNT_BOX_LOGIN', 'Вы зарегистрированы? Заходите!');

