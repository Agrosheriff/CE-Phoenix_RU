cfg_ec_order_status_id_title = Статус заказа
cfg_ec_order_status_id_desc = Установите этот уровень статуса заказа, который присваивается новым заказам.

cfg_ec_order_status_id_default = -- Сохранять статус заказа по умолчанию --
