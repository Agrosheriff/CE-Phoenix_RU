cfg_ps_ewp_public_cert_id_title = Ваш PayPal Public Certificate ID
cfg_ps_ewp_public_cert_id_desc = Идентификатор сертификата, присвоенный вашему сертификату, показанному на странице профиля настроек профиля зашифрованного PayPal.
