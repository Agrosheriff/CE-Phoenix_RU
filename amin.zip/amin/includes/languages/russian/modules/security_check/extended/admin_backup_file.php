<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2019 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

define('MODULE_SECURITY_CHECK_EXTENDED_ADMIN_BACKUP_FILE_TITLE', 'admin/backups/ Доступ к файлам');
define('MODULE_SECURITY_CHECK_EXTENDED_ADMIN_BACKUP_FILE_HTTP_200', 'Backup files in ' . DIR_WS_ADMIN . 'backups/ могут быть доступны и загружены напрямую - отключите общий доступ к этому каталогу в конфигурации вашего веб-сервера.');
?>
