cfg_ps_ewp_working_directory_title = Рабочая директория
cfg_ps_ewp_working_directory_desc = Рабочая директория для размещения временных файлов.
