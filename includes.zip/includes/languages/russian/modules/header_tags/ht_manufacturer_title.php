<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2016 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_MANUFACTURER_TITLE_TITLE', 'Производители');
  define('MODULE_HEADER_TAGS_MANUFACTURER_TITLE_DESCRIPTION', 'Добавить название этого производителя на основной странице');

  define('MODULE_HEADER_TAGS_MANUFACTURER_SEO_SEPARATOR', ' | ');
  