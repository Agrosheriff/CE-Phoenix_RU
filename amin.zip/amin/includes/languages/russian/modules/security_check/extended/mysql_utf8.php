<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2019 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

define('MODULE_SECURITY_CHECK_EXTENDED_MYSQL_UTF8_TITLE', 'Кодировка MySQL UTF-8');
define('MODULE_SECURITY_CHECK_EXTENDED_MYSQL_UTF8_ERROR', 'Некоторые таблицы базы данных должны быть преобразованы в UTF-8 (utf8_unicode_ci). Просмотрите таблицы в разделе Инструменты -&gt; Таблицы базы данных.');
?>
