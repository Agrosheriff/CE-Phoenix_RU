cfg_login_sort_order_title = Сортировка
cfg_login_sort_order_desc = Sort order of display. Lowest is displayed first.
