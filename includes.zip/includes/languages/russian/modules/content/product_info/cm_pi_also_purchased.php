<?php
/*
$Id$
osCommerce, Open Source E-Commerce Solutions
http://www.oscommerce.com
Copyright (c) 2020 osCommerce
Translation to RU from Fredi. Updated 7/01/2020
Released under the GNU General Public License
*/

const MODULE_CONTENT_PRODUCT_INFO_ALSO_PURCHASED_TITLE        = 'Покупают также и эти товары';
const MODULE_CONTENT_PRODUCT_INFO_ALSO_PURCHASED_DESCRIPTION  = 'Показать -Также покупают- блок на странице товара.';

const MODULE_CONTENT_PRODUCT_INFO_ALSO_PURCHASED_PUBLIC_TITLE = 'Рекомендуем! Самые популярные...';

