<?php
/*
$Id$
osCommerce, Open Source E-Commerce Solutions
http://www.oscommerce.com
Copyright (c) 2020 osCommerce
Translation to RU from Fredi. Updated 7/01/2020
Released under the GNU General Public License
*/

define('MODULE_CONTENT_IP_CATEGORY_DESCRIPTION_TITLE', 'Описания категорий и производителей');
define('MODULE_CONTENT_IP_CATEGORY_DESCRIPTION_DESCRIPTION', 'Показать описание категории/производители на уровне товаров в index.php');

