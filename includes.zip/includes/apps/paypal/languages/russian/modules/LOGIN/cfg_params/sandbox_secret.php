cfg_login_sandbox_secret_title = Проверка безопасности
cfg_login_sandbox_secret_desc = Испытание безопасности по проверке полномочий PayPal REST App.
