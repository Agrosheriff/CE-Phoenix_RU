heading_live_account = Live: :акаунт
heading_sandbox_account = Sandbox: :акаунт

retrieving_balance_progress = Получение баланса &hellip;

error_no_accounts_configured = Ошибка: Нет PayPal в реальном времени или Sandbox счет еще был настроен. Пожалуйста, настройте учетную запись PayPal и повторите попытку.
error_balance_retrieval = Ошибка: Баланс PayPal не может быть получен. Пожалуйста, попробуйте еще раз.
