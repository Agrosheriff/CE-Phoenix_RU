<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2018 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_BREADCRUMB_SCHEMA_TITLE', 'Breadcrumb схема JSON-LD');
  define('MODULE_HEADER_TAGS_BREADCRUMB_SCHEMA_DESCRIPTION', 'Добавить Breadcrumb Schema JSON-LD для всех страниц.');
  