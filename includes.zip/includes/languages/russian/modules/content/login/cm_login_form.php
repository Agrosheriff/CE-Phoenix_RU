<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_LOGIN_FORM_TITLE', 'Форма Входа');
  define('MODULE_CONTENT_LOGIN_FORM_DESCRIPTION', 'Показывать форму входа на странице входа');

  define('MODULE_CONTENT_LOGIN_HEADING_RETURNING_CUSTOMER', 'Зарегистрированный покупатель');
  define('MODULE_CONTENT_LOGIN_TEXT_RETURNING_CUSTOMER', 'Я уже покупал в магазине ' . STORE_NAME . '.<br>');

  define('MODULE_CONTENT_LOGIN_TEXT_LOGIN_ERROR', 'Ошибочка вышла: пароль или E-Mail адрес не подходят. Попробуйте поправить или указать другой.');

  define('MODULE_CONTENT_LOGIN_ENTRY_EMAIL_ADDRESS_PLACEHOLDER', 'Email');
  define('MODULE_CONTENT_LOGIN_ENTRY_PASSWORD_PLACEHOLDER', 'Пароль');
  