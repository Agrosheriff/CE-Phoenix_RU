<?php
/*
$Id$
osCommerce, Open Source E-Commerce Solutions
http://www.oscommerce.com
Copyright (c) 2020 osCommerce
Translation to RU from Fredi. Updated 7/01/2020
Released under the GNU General Public License
*/

const MODULE_CONTENT_PRODUCT_INFO_GTIN_TITLE        = 'Штрихкод GTIN';
const MODULE_CONTENT_PRODUCT_INFO_GTIN_DESCRIPTION  = 'Показать GTIN (UPC, EAN) цифры штрихкода на информационной странице товара.';

const MODULE_CONTENT_PRODUCT_INFO_GTIN_PUBLIC_TITLE = 'UPC/EAN:<span class="badge badge-primary badge-pill">%s</span>';
