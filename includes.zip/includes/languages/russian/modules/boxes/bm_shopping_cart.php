<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2018 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

  define('MODULE_BOXES_SHOPPING_CART_TITLE', 'Моя Корзина');
  define('MODULE_BOXES_SHOPPING_CART_DESCRIPTION', 'Показывать содержимое корзины');
  define('MODULE_BOXES_SHOPPING_CART_BOX_TITLE', 'Корзина');
  define('MODULE_BOXES_SHOPPING_CART_BOX_CART_EMPTY', '0 штук');
  