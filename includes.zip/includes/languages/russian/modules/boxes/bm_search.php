<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2018 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_SEARCH_TITLE', 'Поиск');
  define('MODULE_BOXES_SEARCH_DESCRIPTION', 'Показывать поле поиска');
  define('MODULE_BOXES_SEARCH_BOX_TITLE', 'Быстрый поиск');
  define('MODULE_BOXES_SEARCH_BOX_TEXT', 'Введите слова для поиска');
  define('MODULE_BOXES_SEARCH_BOX_ADVANCED_SEARCH', 'Расширенный поиск');
