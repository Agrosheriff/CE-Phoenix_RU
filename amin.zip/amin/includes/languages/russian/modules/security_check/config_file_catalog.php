<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2019 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

define('WARNING_CONFIG_FILE_WRITEABLE', 'Можно сделать несанкционированную или вредоносную запись в конфигурационном файле: ' . DIR_FS_CATALOG . 'includes/configure.php. Это потенциальный риск безопасности - пожалуйста, установите ограниченные права доступа к этому файлу.');
?>
