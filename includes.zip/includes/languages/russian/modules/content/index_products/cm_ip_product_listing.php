<?php
/*
  $Id:

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2018 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_IP_PRODUCT_LISTING_TITLE', 'Список продуктов');
  define('MODULE_CONTENT_IP_PRODUCT_LISTING_DESCRIPTION', 'Показать список продуктов для категории/производители.');
