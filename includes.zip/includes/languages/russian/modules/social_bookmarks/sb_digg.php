<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_SOCIAL_BOOKMARKS_DIGG_TITLE', 'Digg');
  define('MODULE_SOCIAL_BOOKMARKS_DIGG_DESCRIPTION', 'Рассказать о товаре на Digg.');
  define('MODULE_SOCIAL_BOOKMARKS_DIGG_PUBLIC_TITLE', 'Рассказать на Digg');
?>
