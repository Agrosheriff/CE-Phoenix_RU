<?php
/*
$Id$
osCommerce, Open Source E-Commerce Solutions
http://www.oscommerce.com
Copyright (c) 2020 osCommerce
Translation to RU from Fredi. Updated 7/01/2020
Released under the GNU General Public License
*/

define('MODULE_CONTENT_TESTIMONIALS_LIST_TITLE', 'Список рекомендаций');
define('MODULE_CONTENT_TESTIMONIALS_LIST_DESCRIPTION', 'Показывать Список рекомендаций.');

define('MODULE_CONTENT_TESTIMONIALS_LIST_NO_TESTIMONIALS', 'Нет рекомендаций для показа...');

define('MODULE_CONTENT_TESTIMONIALS_LIST_WRITERS_NAME_DATE', 'Написано с %s по %s.');

define('MODULE_CONTENT_TESTIMONIALS_DISPLAY_NUMBER', 'Показать <b>%s</b> от <b>%s</b> (до <b>%s</b> рекомендаций)');
