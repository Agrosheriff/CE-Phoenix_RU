<?php
/*
  $Id$

  Modules Control Version 1.2.0
  by @raiwa // Rainer Schmied // info@oscaddons.com // www,oscaddons.com

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2016 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_NAVBAR_MC_TITLE', 'НавБар Контроль модулей');
  define('MODULE_CONTENT_NAVBAR_MC_DESCRIPTION', 'Показать панель навигации с поддержкой управления модулями на вашем сайте. <div class="secWarning">Этот модуль имеет несколько подмодулей, которые также должны быть установлены.<br><br>Admin > Modules > Navbar Modules</div>');
  