cfg_hs_status_title = Статус
cfg_hs_status_desc = Установите для этого Live, чтобы начать принимать платежи или в тестовую среду для выполнения тестовых заказов.

cfg_hs_status_live = Live
cfg_hs_status_sandbox = Sandbox
cfg_hs_status_disabled = Отключено
