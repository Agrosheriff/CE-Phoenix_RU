<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2019 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

define('EMAIL_TEXT_SUBJECT', 'Заказ');
define('EMAIL_TEXT_ORDER_NUMBER', 'Номер заказа:');
define('EMAIL_TEXT_INVOICE_URL', 'Информация о Заказе:');
define('EMAIL_TEXT_DATE_ORDERED', 'Дата Заказа:');
define('EMAIL_TEXT_PRODUCTS', 'Вы заказали:');
define('EMAIL_TEXT_SUBTOTAL', 'Стоимость:'); 
define('EMAIL_TEXT_TAX', 'Налоги:        ');
define('EMAIL_TEXT_SHIPPING', 'Способ доставки: ');
define('EMAIL_TEXT_TOTAL', 'Всего:     ');
define('EMAIL_TEXT_DELIVERY_ADDRESS', 'Адрес доставки');
define('EMAIL_TEXT_BILLING_ADDRESS', 'Адрес покупателя');
define('EMAIL_TEXT_PAYMENT_METHOD', 'Способ оплаты');

define('EMAIL_SEPARATOR', '------------------------------------------------------');
define('TEXT_EMAIL_VIA', 'через');
?>