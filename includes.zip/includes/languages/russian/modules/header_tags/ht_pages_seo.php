<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2015 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_PAGES_SEO_TITLE', 'SEO - Страницы');
  define('MODULE_HEADER_TAGS_PAGES_SEO_DESCRIPTION', 'Добавить определенные SEO элементы при редактировании страниц (например: specials.php), в заголовке страницы');

  define('MODULE_HEADER_TAGS_PAGES_SEO_HELPER', 'Вам нужно добавить SEO элементы на вашем языковые файлы для каждой страницы.');
  define('MODULE_HEADER_TAGS_PAGES_SEO_SEPARATOR', ' | ');

