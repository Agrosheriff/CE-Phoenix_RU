<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2019 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Оформление заказа');
define('NAVBAR_TITLE_2', 'Способ доставки');

define('HEADING_TITLE', 'Информация о доставке заказа'); 

define('TABLE_HEADING_SHIPPING_ADDRESS', 'Адрес доставки');
define('TABLE_HEADING_SHIPPING_METHOD', 'Способ доставки');

define('TEXT_ENTER_SHIPPING_INFORMATION', 'На данный момент доступен единственный способ доставки:');
define('ERROR_NO_SHIPPING_AVAILABLE_TO_SHIPPING_ADDRESS', 'Доставка не может быть осуществлена по выбранному Вами адресу. Выберите другой или введите новый адрес для доставки Вашей покупки.');

define('BUTTON_CONTINUE_CHECKOUT_PROCEDURE', 'Продолжить оформление заказа');
