cfg_proxy_title = Proxy
cfg_proxy_desc = Отправить Curl API запросы через этот прокси-сервер. (host:port, напр.: 123.45.67.89:8080 или proxy.example.com:8080)
