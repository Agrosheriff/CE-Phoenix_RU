<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

define('MODULE_SECURITY_CHECK_EXTENDED_ADMIN_HTTP_AUTHENTICATION_TITLE', 'Админ аутентификация HTTP');
define('MODULE_SECURITY_CHECK_EXTENDED_ADMIN_HTTP_AUTHENTICATION_ERROR', 'HTTP-аутентификация не была настроена для инструмента администрирования ФЕНИКС - пожалуйста, настройте это в настройках своего веб-сервера, чтобы еще больше защитить инструмент администрирования от несанкционированного доступа.');
?>
