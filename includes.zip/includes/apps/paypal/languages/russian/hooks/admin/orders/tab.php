button_dialog_capture = Захват &hellip;
button_details = Детали
button_dialog_refund = Возврат &hellip;
button_view_at_paypal = Просмотреть в PayPal
button_dialog_void = Пусто &hellip;

tab_title = PayPal

dialog_capture_title = Захват оплаты
dialog_capture_body = Полная или частичная сумма может быть зафиксирована.
dialog_capture_amount_field_title = Сумма:
dialog_capture_last_capture_field_title = Это последний захват (release <span id="ppCaptureVoidedValue"></span> : Возврат валюты клиенту).
dialog_capture_button_capture = Сумма захвата
dialog_capture_button_cancel = Отмена

dialog_void_title = Недействительный платеж
dialog_void_body = Вы действительно хотите аннулировать авторизованный платеж?
dialog_void_button_void = Недействительный платеж
dialog_void_button_cancel = Отмена

dialog_refund_title = Возврат платежа (Возмещение).
dialog_refund_body = Выберите платеж который идет на возврат для выполнения:
dialog_refund_payment_title = Возмещение: сумма для клиента.
dialog_refund_button_refund = Возврат платежа
dialog_refund_button_cancel = Отмена
