<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2019 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Мой Кабинет'); 
define('NAVBAR_TITLE_2', 'Изменить Пароль'); 

define('HEADING_TITLE', 'Мой пароль'); 

define('MY_PASSWORD_TITLE', 'Мой пароль'); 

define('SUCCESS_PASSWORD_UPDATED', 'Вы успешно обновили свой Пароль.');
define('ERROR_CURRENT_PASSWORD_NOT_MATCHING', 'Вы указали неверный пароль, укажите пароль, который Вы вводили при регистрации и попробуйте войти снова.');
?>
