cfg_ec_account_optional_title = Учетная запись PayPal необязательна
cfg_ec_account_optional_desc = Установите для этого значение True, чтобы позволить клиентам приобретать через PayPal, не требуя учетной записи PayPal.

cfg_ec_account_optional_true = True
cfg_ec_account_optional_false = False
