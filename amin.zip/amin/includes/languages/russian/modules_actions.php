<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2018 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

const HEADING_TITLE          = 'Действия';

const TABLE_HEADING_FILE     = 'Файл';
const TABLE_HEADING_ACTION   = 'Действие';
const TABLE_HEADING_CLASS    = 'Класс';
const TABLE_HEADING_METHOD   = 'Метод';

const TEXT_ACTIONS_DIRECTORY = 'Рабочая директория:';
