<?php
 /*
  $Id:orders_customer_tab.php$

  $Path:catalog\includes\languages\english\modules\hooks\admin\$

    language defs for customer orders hook
    author: John Ferguson @BrockleyJohn john@sewebsites.net
  Translation to RU from Fredi. Updated 7/01/2020

  20191007 Denkster added Order_Editor_v1.2.5_for_2.3.4_BS
*/
define('TABLE_HEADING_PAYMENT_METHOD','Способ оплаты');
define('TABLE_HEADING_SHIPPING_METHOD','Способ доставки');
define('TAB_CUSTOMER_ORDERS','Все заказы');