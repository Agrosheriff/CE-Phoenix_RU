cfg_login_sandbox_client_id_title = Test Client ID
cfg_login_sandbox_client_id_desc = The Client ID of the PayPal REST App Test Credentials.
