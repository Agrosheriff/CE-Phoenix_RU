cfg_dp_cards_title = Карты
cfg_dp_cards_desc = Выберите типы карт, с которых можно осуществлять платежи.
