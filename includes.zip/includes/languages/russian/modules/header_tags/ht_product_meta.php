<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2016 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_PRODUCT_META_TITLE', 'Товар Meta SEO');
  define('MODULE_HEADER_TAGS_PRODUCT_META_DESCRIPTION', 'Добавить элементы META CEO для товаров, в шапку страниц товаров');

