cfg_ps_ewp_paypal_cert_title = Местоположение PayPal Public Certificate
cfg_ps_ewp_paypal_cert_desc = Местоположение и имя открытого сертификата PayPal для использования для шифрования параметров.
