<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce
  Translation to RU from Fredi. Updated 17/01/2020
  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_PHOENIX_ADDONS_TITLE', 'Последние сертифицированные модули');
define('MODULE_ADMIN_DASHBOARD_PHOENIX_ADDONS_DESCRIPTION', 'Последние сертифицированные модули для членов Клуба Феникс');

define('MODULE_ADMIN_DASHBOARD_PHOENIX_ADDONS_OWNER', 'От');
define('MODULE_ADMIN_DASHBOARD_PHOENIX_ADDONS_RATING', 'Рейтинг');
define('MODULE_ADMIN_DASHBOARD_PHOENIX_ADDONS_DATE', 'Дата');

define('MODULE_ADMIN_DASHBOARD_PHOENIX_JOIN_CLUB', 'Стать членом Клуба');
define('MODULE_ADMIN_DASHBOARD_PHOENIX_VIEW_ALL', 'Посмотреть полный список сертифицированных дополнений');
