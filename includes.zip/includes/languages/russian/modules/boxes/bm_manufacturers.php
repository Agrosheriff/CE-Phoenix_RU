<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2018 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

  define('MODULE_BOXES_MANUFACTURERS_TITLE', 'Производители');
  define('MODULE_BOXES_MANUFACTURERS_DESCRIPTION', 'Показывать список производителей');
  define('MODULE_BOXES_MANUFACTURERS_BOX_TITLE', 'Производители');
