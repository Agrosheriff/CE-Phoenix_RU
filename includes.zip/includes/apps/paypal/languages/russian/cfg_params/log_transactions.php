cfg_log_transactions_title = Журнал транзакций
cfg_log_transactions_desc = Установите уровень операций, которые должны быть зарегистрированы.

cfg_log_transactions_all = Все
cfg_log_transactions_errors = Ошибки
cfg_log_transactions_disabled = Выключен
