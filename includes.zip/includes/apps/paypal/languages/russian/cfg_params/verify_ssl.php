cfg_verify_ssl_title = Проверка SSL
cfg_verify_ssl_desc = Включите это для проверки сертификата SSL при выполнении API вызовов к серверам системы PayPal.

cfg_verify_ssl_true = Вкл.
cfg_verify_ssl_false = Выкл.
