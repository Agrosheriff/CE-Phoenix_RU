<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2016 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_CATEGORY_SEO_TITLE', 'Категории SEO');
  define('MODULE_HEADER_TAGS_CATEGORY_SEO_DESCRIPTION', 'Добавьте элементы SEO, которые вы определили для категории, к базовому коду страницы категории (так называемый мета-описания и мета ключевые слова). Хорошо для SEO.');

