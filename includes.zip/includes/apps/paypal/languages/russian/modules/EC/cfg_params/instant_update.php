cfg_ec_instant_update_title = Мгновенное обновление
cfg_ec_instant_update_desc = Включите это, чтобы PayPal получал список тарифов доставки после того, как клиент выбрал свой почтовый адрес во время потока экспресс-оплаты. <br /> <br /> <em> Для мгновенного обновления требуется, чтобы SSL был включен в вашем магазине.</em>

cfg_ec_instant_update_enabled = Вкл.
cfg_ec_instant_update_disabled = Выкл.
