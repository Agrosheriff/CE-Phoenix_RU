cfg_login_status_title = Статус
cfg_login_status_desc = Установите на Live для использования учетных данных API Live REST или для проверки использования учетных данных Test.

cfg_login_status_live = Живая
cfg_login_status_test = Тест
cfg_login_status_disabled = Отключено
