<?php
/*
  $Id$

  Copyright (c) 2016:
    Dan Cole - @Dan Cole
    James Keebaugh - @kymation
    Lambros - @Tsimi
    Rainer Schmied - @raiwa

  Translation to RU from Fredi. Updated 7/01/2020
*/

  define('MODULE_CONTENT_SC_NO_PRODUCTS_TITLE', 'Сообщение «Нет товаров в Корзине»');
  define('MODULE_CONTENT_SC_NO_PRODUCTS_DESCRIPTION', 'Показать сообщение «Нет товаров в Корзине» на странице Корзины.');
  
  define('MODULE_CONTENT_SC_NO_PRODUCTS_TEXT_CART_EMPTY', 'В вашей корзине нет товаров!');
  define('MODULE_CONTENT_SC_NO_PRODUCTS_BUTTON_CONTINUE', 'Продолжить');
