cfg_login_theme_title = Тема
cfg_login_theme_desc = Тема, используемая для стиля кнопки входа.

cfg_login_theme_blue = Синий
cfg_login_theme_neutral = Нейтральный
