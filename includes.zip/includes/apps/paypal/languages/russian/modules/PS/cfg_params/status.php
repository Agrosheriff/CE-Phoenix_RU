cfg_ps_status_title = Статус
cfg_ps_status_desc = Установите на Live, чтобы начать принимать платежи или на Sandbox для выполнения тестовых заказов.

cfg_ps_status_live = Живая
cfg_ps_status_sandbox = Sandbox
cfg_ps_status_disabled = Отключено
