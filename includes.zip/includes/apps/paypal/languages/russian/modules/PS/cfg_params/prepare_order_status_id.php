cfg_ps_prepare_order_status_id_title = Подготовка статуса заказа
cfg_ps_prepare_order_status_id_desc = Установите уровень статуса заказа, который присвоен заказам подготовленным клиентом.
cfg_ps_prepare_order_status_id_default = -- Сохранить статус заказа по умолчанию --
