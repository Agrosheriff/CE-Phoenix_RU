<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

define('MODULE_CONTENT_ACCOUNT_SET_PASSWORD_TITLE', 'Установить пароль личного Кабинета');
define('MODULE_CONTENT_ACCOUNT_SET_PASSWORD_DESCRIPTION', 'Установить пароль если пароль не был задан ранее.');

define('MODULE_CONTENT_ACCOUNT_SET_PASSWORD_SET_PASSWORD_LINK_TITLE', 'Установить пароль для личного Кабинета.');

define('MODULE_CONTENT_ACCOUNT_SET_PASSWORD_NAVBAR_TITLE_1', 'Мой Кабинет');
define('MODULE_CONTENT_ACCOUNT_SET_PASSWORD_NAVBAR_TITLE_2', 'Установить пароль');

define('MODULE_CONTENT_ACCOUNT_SET_PASSWORD_HEADING_TITLE', 'Установить пароль');

define('MODULE_CONTENT_ACCOUNT_SET_PASSWORD_SET_PASSWORD_TITLE', 'Установить пароль');

define('MODULE_CONTENT_ACCOUNT_SET_PASSWORD_SUCCESS_PASSWORD_SET', 'Ваш пароль сохранен.');
?>
