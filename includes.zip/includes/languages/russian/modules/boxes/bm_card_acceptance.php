<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2019 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

  define('MODULE_BOXES_CARD_ACCEPTANCE_TITLE', 'Принимаем карты');
  define('MODULE_BOXES_CARD_ACCEPTANCE_DESCRIPTION', 'Логотипы принимаемых карт');

  define('MODULE_BOXES_CARD_ACCEPTANCE_SHOWN_CARDS', 'Показано карт');
  define('MODULE_BOXES_CARD_ACCEPTANCE_NEW_CARDS', 'Новые карты');
  define('MODULE_BOXES_CARD_ACCEPTANCE_DRAG_HERE', 'Перетащить сюда');

  define('MODULE_BOXES_CARD_ACCEPTANCE_BOX_TITLE', 'Мы принимаем');