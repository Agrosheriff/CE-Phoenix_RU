<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2018 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_INFORMATION_TITLE', 'ИНФОРМАЦИЯ');
  define('MODULE_BOXES_INFORMATION_DESCRIPTION', 'Показать линки на страницы');
   define('MODULE_BOXES_INFORMATION_BOX_TITLE', 'Информация');
  
    const MODULE_BOXES_INFORMATION_BOX_DATA = array(
    'privacy.php' => 'Безопасность',
    'conditions.php' => 'Условия использования',
    'shipping.php' => 'Доставка',
    'contact_us.php' => 'Контакты'
  );
  
