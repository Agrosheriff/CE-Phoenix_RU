cfg_hs_status_title = Status
cfg_hs_status_desc = Set this to Live to start accepting payments or to Sandbox to perform test orders.

cfg_hs_status_live = Live
cfg_hs_status_sandbox = Sandbox
cfg_hs_status_disabled = Disabled
