<?php
/*
  $Id$

  Copyright (c) 2016:
    Dan Cole - @Dan Cole
    James Keebaugh - @kymation
    Lambros - @Tsimi
    Rainer Schmied - @raiwa

  Translation to RU from Fredi. Updated 7/01/2020
*/

  define('MODULE_CONTENT_SC_TITLE_TITLE', 'Заголовок на странице Корзины');
  define('MODULE_CONTENT_SC_TITLE_DESCRIPTION', 'Показать Заголовок на странице Корзины.');
  
  define('MODULE_CONTENT_SC_TITLE_PUBLIC_TITLE', 'Что лежит в моей корзине?');
