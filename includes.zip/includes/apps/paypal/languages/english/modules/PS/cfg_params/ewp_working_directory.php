cfg_ps_ewp_working_directory_title = Working Directory
cfg_ps_ewp_working_directory_desc = The working directory to use for temporary files.
