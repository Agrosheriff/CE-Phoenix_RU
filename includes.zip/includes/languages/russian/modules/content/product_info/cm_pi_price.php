<?php
/*
$Id$
osCommerce, Open Source E-Commerce Solutions
http://www.oscommerce.com
Copyright (c) 2020 osCommerce
Translation to RU from Fredi. Updated 7/01/2020
Released under the GNU General Public License
*/

const MODULE_CONTENT_PI_PRICE_TITLE = 'Стоимость товара';
const MODULE_CONTENT_PI_PRICE_DESCRIPTION = 'Показать: Стоимость товара на странице товара.';

const MODULE_CONTENT_PI_PRICE_DISPLAY_SPECIAL = '<del>%2$s</del> <span class="productPrice text-danger productSpecialPrice">%1$s</span>';
const MODULE_CONTENT_PI_PRICE_DISPLAY         = '<span class="productPrice">%s</span>';

