<?php
/*
  $Id$

  Copyright (c) 2016:
    Dan Cole - @Dan Cole
    James Keebaugh - @kymation
    Lambros - @Tsimi
    Rainer Schmied - @raiwa

  Translation to RU from Fredi. Updated 7/01/2020
*/

  define('MODULE_CONTENT_SC_CHECKOUT_TITLE', 'Оформить заказ');
  define('MODULE_CONTENT_SC_CHECKOUT_DESCRIPTION', 'Показать кнопку оформления заказа на странице корзины');
  
  define('MODULE_CONTENT_SC_CHECKOUT_BUTTON_CHECKOUT', 'Подтвердить');
  define('MODULE_CONTENT_SC_CHECKOUT_ALTERNATIVE_CHECKOUT_METHODS', '- ИЛИ ЖЕ -');
