cfg_ps_prepare_order_status_id_title = Preparing Order Status
cfg_ps_prepare_order_status_id_desc = Set this to the order status level that customer prepared orders are assigned to.

cfg_ps_prepare_order_status_id_default = -- Store Default Order Status --
