<?php
/*
$Id$
osCommerce, Open Source E-Commerce Solutions
http://www.oscommerce.com
Copyright (c) 2020 osCommerce
Translation to RU from Fredi. Updated 7/01/2020
Released under the GNU General Public License
*/

define('MODULE_CONTENT_UPCOMING_PRODUCTS_TITLE', 'Ожидаемые товары');
define('MODULE_CONTENT_UPCOMING_PRODUCTS_DESCRIPTION', 'Показать модуль "Ожидаемые товары" на гл. стр.');

define('MODULE_CONTENT_UPCOMING_PRODUCTS_TABLE_HEADING_PRODUCTS', 'Ожидаемые товары');
define('MODULE_CONTENT_UPCOMING_PRODUCTS_TABLE_HEADING_DATE_EXPECTED', 'Дата поступления');

