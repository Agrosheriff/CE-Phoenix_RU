cfg_ps_zone_title = Payment Zone
cfg_ps_zone_desc = Enable this payment module globally or limit it to customers shipping to the selected zone only.

cfg_ps_zone_global = -- Global --
