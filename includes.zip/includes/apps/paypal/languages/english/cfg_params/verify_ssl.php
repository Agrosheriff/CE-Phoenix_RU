cfg_verify_ssl_title = Verify SSL
cfg_verify_ssl_desc = Set this to True to verify the SSL certificate when making API calls to PayPal's servers.

cfg_verify_ssl_true = True
cfg_verify_ssl_false = False
