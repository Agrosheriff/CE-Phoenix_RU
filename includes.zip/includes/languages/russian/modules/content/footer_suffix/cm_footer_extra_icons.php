<?php
/*
$Id$
osCommerce, Open Source E-Commerce Solutions
http://www.oscommerce.com
Copyright (c) 2020 osCommerce
Translation to RU from Fredi. Updated 7/01/2020
Released under the GNU General Public License
*/

define('MODULE_CONTENT_FOOTER_EXTRA_ICONS_TITLE', 'Иконки платежных систем');
define('MODULE_CONTENT_FOOTER_EXTRA_ICONS_DESCRIPTION', 'Добавляет значки торговых марок в область дополнительных нижних колонтитулов вашего сайта. <div class = "secInfo"> Доступные значки торговых марок отображаются здесь: https://fontawesome.com/icons?d=gallery&s=brands&c=payments-shopping </ div>');

define('MODULE_CONTENT_FOOTER_EXTRA_ICONS_TEXT', '');

