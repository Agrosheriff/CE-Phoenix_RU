<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2019 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Оформление заказа');
define('NAVBAR_TITLE_2', 'Способ оплаты заказа');

define('HEADING_TITLE', 'Способ оплаты заказа');

define('TABLE_HEADING_BILLING_ADDRESS', 'Адрес покупателя'); 

define('TABLE_HEADING_PAYMENT_METHOD', 'Способ оплаты');

define('TEXT_ENTER_PAYMENT_INFORMATION', 'В настоящее время это единственный способ оплаты, доступный для использования в этом заказе.');

define('TITLE_CONTINUE_CHECKOUT_PROCEDURE', 'Продолжить оформление заказа');
