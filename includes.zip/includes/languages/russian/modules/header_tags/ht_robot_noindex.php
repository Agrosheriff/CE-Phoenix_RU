<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2012 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_ROBOT_NOINDEX_TITLE', 'NoIndex для роботов');
  define('MODULE_HEADER_TAGS_ROBOT_NOINDEX_DESCRIPTION', 'Добавить robot noindex теги на определенные страницы сайта');
?>
