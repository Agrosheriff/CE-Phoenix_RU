<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2016 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_PRODUCT_OPENGRAPH_TITLE', 'Open Graph Meta Tags Для продуктов');
  define('MODULE_HEADER_TAGS_PRODUCT_OPENGRAPH_DESCRIPTION', 'Добавить Open Graph Meta Tags на ваши страницы продуктов, это хорошо длля Facebook и для Pinterest Rich Pins.');

  define('MODULE_HEADER_TAGS_PRODUCT_OPENGRAPH_TEXT_IN_STOCK', 'в наличии');
  define('MODULE_HEADER_TAGS_PRODUCT_OPENGRAPH_TEXT_OUT_OF_STOCK', 'нет в наличии');
  
