cfg_ps_ewp_paypal_cert_title = PayPal Public Certificate
cfg_ps_ewp_paypal_cert_desc = The location and filename of the PayPal Public Certificate to use for encrypting the parameters.
