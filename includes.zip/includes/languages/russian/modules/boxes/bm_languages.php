<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2018 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_LANGUAGES_TITLE', 'Языки');
  define('MODULE_BOXES_LANGUAGES_DESCRIPTION', 'Показывать выбор языка');
  define('MODULE_BOXES_LANGUAGES_BOX_TITLE', 'Языки');
