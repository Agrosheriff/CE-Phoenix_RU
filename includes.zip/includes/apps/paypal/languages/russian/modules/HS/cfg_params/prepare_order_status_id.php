cfg_hs_prepare_order_status_id_title = Подготовка статуса заказа
cfg_hs_prepare_order_status_id_desc = Установите уровень статуса заказа, который присваивается заказам клиентов.

cfg_hs_prepare_order_status_id_default = -- Сохранить по умолчанию --
