<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2016 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

  const MODULE_CONTENT_IP_CATEGORY_IMAGES_TITLE        = 'Категории. Изображения';
  const MODULE_CONTENT_IP_CATEGORY_IMAGES_DESCRIPTION  = 'Показать модуль "Категории. Изображения" на ваших страницах продуктов.';
  const MODULE_CONTENT_IP_CATEGORY_IMAGES_HEADING      = 'ТОВАРЫ ПО КАТЕГОРИЯМ';
  const MODULE_CONTENT_IP_CATEGORY_IMAGES_SEE_MORE     = '(смотреть более)';
  