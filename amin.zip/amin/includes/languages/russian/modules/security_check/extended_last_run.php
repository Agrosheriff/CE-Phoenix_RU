<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

define('MODULE_SECURITY_CHECK_EXTENDED_LAST_RUN_OLD', 'Прошло уже более 30 дней с последней расширенной проверки безопасности. Запустите расширенную проверку безопасности повторно в Инструментах -&gt; Проверка безопасности.');
?>
