<?php
/*
  $Id $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Выход');
define('NAVBAR_TITLE', 'Выход');
define('TEXT_MAIN', 'Вы успешно вышли.<br>Содержимое Вашей корзины сохранено, Вы можете вернуться и оформить Ваши покупки позже.<br>Возвращайтесь поскорее, наши продукты это то, что вы искали и они вас ждут!'); 
?>
