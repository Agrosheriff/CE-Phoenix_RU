<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_TABLE_CLICK_JQUERY_TITLE', 'Строка таблицы Click jQuery');
  define('MODULE_HEADER_TAGS_TABLE_CLICK_JQUERY_DESCRIPTION', 'Добавить Table Row Click jQuery на указанные страницы');
?>
