<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Мои данные');
define('NAVBAR_TITLE_2', 'Редактирование');

define('HEADING_TITLE', 'Мои настройки');

define('SUCCESS_ACCOUNT_UPDATED', 'Ваш профиль обновлен.');

