<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2018 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Проверка безопасности');
define('HEADING_TITLE', 'Проверка безопасности');

define('TEXT_INFORMATION', 'Мы обнаружили, что Ваш браузер сформировал другую SSL ID сессию, используемую в наших защищенных страницах.<br /><br />Для обеспечения безопасности вам необходимо зайти на сайт через ваш акаунт, чтобы продолжить покупки в Интернете.<br /><br />Некоторые браузеры, такие как Konqueror 3.1 не имеют возможности генерации безопасной ID SSL сеанс автоматически, что мы требуем. Если вы используете такой браузер, рекомендуем перейти на другой браузер, такой как <a class="btn btn-light btn-sm" role="button" href="http://www.microsoft.com/ie/" target="_blank">Microsoft Internet Explorer</a> или <a class="btn btn-light btn-sm" role="button" href="http://channels.netscape.com/ns/browsers/download_other.jsp" target="_blank">Netscape</a> или <a class="btn btn-light btn-sm" role="button" href="http://www.mozilla.org/releases/" target="_blank">Mozilla</a>, чтобы продолжить покупки в Интернете.<br /><br />Мы применяем этот уровень безопасности для вашей пользы, и извиняемся за временные неудобства вызваные этой опцией.<br /><br />Пожалуйста <a class="btn btn-success btn-sm" role="button" href="' . tep_href_link('contact_us.php', '', 'SSL') . '">свяжитесь с администрацией магазина</a> если у вас есть какие-либо вопросы, связанные с этим требованием безопасности, либо продолжайте делать покупки в Интернет.');

define('BOX_INFORMATION_HEADING', 'Секретность');
define('BOX_INFORMATION', 'Наши проверки SSL-ID сессии генерируются автоматически в вашем браузере на каждый запрос на безопасную страницу, созданную на этом сервере.<br /><br />Эта проверка гарантирует, что это вы тот, кто находится на этом сайте с вашего акаунта, а не кого-то другой.');

