<?php
/*
$Id$
osCommerce, Open Source E-Commerce Solutions
http://www.oscommerce.com
Copyright (c) 2020 osCommerce
Translation to RU from Fredi. Updated 7/01/2020
Released under the GNU General Public License
*/

const MODULE_CONTENT_PI_GALLERY_TITLE = 'Галерея';
const MODULE_CONTENT_PI_GALLERY_DESCRIPTION = 'Показать картинки товара на странице товара';

