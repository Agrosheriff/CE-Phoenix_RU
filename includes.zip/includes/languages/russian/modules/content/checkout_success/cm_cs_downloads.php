<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_CHECKOUT_SUCCESS_DOWNLOADS_TITLE', 'Скачать');
  define('MODULE_CONTENT_CHECKOUT_SUCCESS_DOWNLOADS_DESCRIPTION', 'Показывать ссылку на скачивание на странице успешного оформления заказа');

  define('TABLE_HEADING_DOWNLOAD_DATE', 'Действительна до: ');
  define('TABLE_HEADING_DOWNLOAD_COUNT', ' осталось скачиваний ');
  define('HEADING_DOWNLOAD', 'Скачать товар:');
  define('FOOTER_DOWNLOAD', 'Вы можете скачать товар \'%s\'');
