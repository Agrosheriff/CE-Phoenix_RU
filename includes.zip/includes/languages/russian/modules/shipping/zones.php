<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2019 osCommerce FFR
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

define('MODULE_SHIPPING_ZONES_TEXT_TITLE', 'Тариф для зоны. EMS Internacional');
define('MODULE_SHIPPING_ZONES_TEXT_DESCRIPTION', 'зональный базовый тариф');
define('MODULE_SHIPPING_ZONES_TEXT_WAY', 'Доставка EMS Avia');
define('MODULE_SHIPPING_ZONES_TEXT_UNITS', 'Кг.');
define('MODULE_SHIPPING_ZONES_INVALID_ZONE', 'Для выбранной страны нет возможности доставки ');
define('MODULE_SHIPPING_ZONES_UNDEFINED_RATE', 'Стоимость пересылки сейчас не может быть определена ');
?>
