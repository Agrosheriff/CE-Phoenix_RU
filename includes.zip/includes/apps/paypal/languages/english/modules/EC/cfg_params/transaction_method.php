cfg_ec_transaction_method_title = Transaction Method
cfg_ec_transaction_method_desc = Set this to Sale to immediately capture the funds for every order made.

cfg_ec_transaction_method_authorize = Authorize
cfg_ec_transaction_method_sale = Sale
