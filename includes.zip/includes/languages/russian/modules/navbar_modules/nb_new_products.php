<?php
/*
$Id$
osCommerce, Open Source E-Commerce Solutions
http://www.oscommerce.com
Copyright (c) 2020 osCommerce
Translation to RU from Fredi. Updated 7/01/2020
Released under the GNU General Public License
*/

define('MODULE_NAVBAR_NEW_PRODUCTS_TITLE', 'Новый товар');
define('MODULE_NAVBAR_NEW_PRODUCTS_DESCRIPTION', 'Показать ссылку на Новый товар в Панели навигации.');

define('MODULE_NAVBAR_NEW_PRODUCTS_PUBLIC_TEXT', '<i title="Новинки" class="fas fa-list fa-fw"></i><span class="d-inline d-sm-none d-md-inline"> Новинки</span>');

