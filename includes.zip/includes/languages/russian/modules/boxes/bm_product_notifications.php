<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2018 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_PRODUCT_NOTIFICATIONS_TITLE', 'Уведомления');
  define('MODULE_BOXES_PRODUCT_NOTIFICATIONS_DESCRIPTION', 'Показывать Уведомления на странице товара');
  define('MODULE_BOXES_PRODUCT_NOTIFICATIONS_BOX_TITLE', 'Уведомления');
  define('MODULE_BOXES_PRODUCT_NOTIFICATIONS_BOX_NOTIFY', 'Уведомить меня об изменениях товара <strong>%s</strong>');
  define('MODULE_BOXES_PRODUCT_NOTIFICATIONS_BOX_NOTIFY_REMOVE', 'Не уведомлять меня об изменениях товара <strong>%s</strong>');
  
  define('MODULE_BOXES_PRODUCT_NOTIFICATIONS_VIEW', '<i class="fas fa-eye"></i> Показать все');
