cfg_proxy_title = Proxy
cfg_proxy_desc = Send Curl API requests through this proxy server. (host:port, eg: 123.45.67.89:8080 or proxy.example.com:8080)
