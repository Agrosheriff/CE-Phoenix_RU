<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2018 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

  define('MODULE_BOXES_CATEGORIES_TITLE', 'Категории товаров');
  define('MODULE_BOXES_CATEGORIES_DESCRIPTION', 'Показывать блок Категории в панели навигации');
  define('MODULE_BOXES_CATEGORIES_BOX_TITLE', 'Категории товаров:');
