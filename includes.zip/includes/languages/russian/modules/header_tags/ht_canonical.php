<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2019 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_CANONICAL_TITLE', 'Канонические ссылки');
  define('MODULE_HEADER_TAGS_CANONICAL_DESCRIPTION', 'Добавить канонические ссылки для страниц category/product.  <div class="secWarning">Обратите внимание, что атрибуты hreflang в этом модуле не поддерживаются, что повлияет на вас, если в вашем магазине более одного языка.<br><br>Вам следует обратиться за советом к хорошему консультанту по SEO. (обратитесь к Jack_mcs на форуме поддержки osCommerce).</div>');
  