cfg_ec_transaction_method_title = Метод оплаты
cfg_ec_transaction_method_desc = Установите это на продажи, чтобы немедленно захватить средства для каждого сделанного заказа.

cfg_ec_transaction_method_authorize = Авторизация
cfg_ec_transaction_method_sale = Продажи
