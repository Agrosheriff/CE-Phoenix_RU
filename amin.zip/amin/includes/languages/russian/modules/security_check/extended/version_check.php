<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

define('MODULE_SECURITY_CHECK_EXTENDED_VERSION_CHECK_TITLE', 'Проверка версии');
define('MODULE_SECURITY_CHECK_EXTENDED_VERSION_CHECK_ERROR', 'Проверка новой версии была выполнена более 30 дней назад. Проверьте, доступна ли новая версия.');
?>
