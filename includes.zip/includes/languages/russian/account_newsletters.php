<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Мой акаунт');
define('NAVBAR_TITLE_2', 'Рассылка');

define('HEADING_TITLE', 'Рассылка новостей');

define('MY_NEWSLETTERS_GENERAL_NEWSLETTER', 'Новости магазина');
define('MY_NEWSLETTERS_GENERAL_NEWSLETTER_DESCRIPTION', 'Новости магазина, новинки, скидки и другие новости.');

define('SUCCESS_NEWSLETTER_UPDATED', 'Информация о Вашей подписке на рассылку обновлена.');
?>
