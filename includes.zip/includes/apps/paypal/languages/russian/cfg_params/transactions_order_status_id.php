cfg_transactions_order_status_id_title = Статус транзакций Заказов
cfg_transactions_order_status_id_desc = Установите для частного Заказа уровень статуса, что бы информация о транзакции должна быть сохранена.
