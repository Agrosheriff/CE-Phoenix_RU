<?php
/*
$Id$
osCommerce, Open Source E-Commerce Solutions
http://www.oscommerce.com
Copyright (c) 2020 osCommerce
Translation to RU from Fredi. Updated 7/01/2020
Released under the GNU General Public License
*/

const MODULE_CONTENT_PI_BUY_TITLE       = 'Кнопка купить';
const MODULE_CONTENT_PI_BUY_DESCRIPTION = 'Показать кнопку купить на странице product_info';

const MODULE_CONTENT_PI_BUY_BUTTON_TEXT = 'Добавить в корзину';
