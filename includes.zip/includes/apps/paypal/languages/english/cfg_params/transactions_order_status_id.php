cfg_transactions_order_status_id_title = Transactions Order Status
cfg_transactions_order_status_id_desc = Set this to the private order status level where transaction information should be stored.
