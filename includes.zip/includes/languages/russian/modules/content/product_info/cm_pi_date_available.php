<?php
/*
$Id$
osCommerce, Open Source E-Commerce Solutions
http://www.oscommerce.com
Copyright (c) 2020 osCommerce
Translation to RU from Fredi. Updated 7/01/2020
Released under the GNU General Public License
*/

const MODULE_CONTENT_PI_DATE_AVAILABLE_TITLE       = 'Дата поступления в продажу';
const MODULE_CONTENT_PI_DATE_AVAILABLE_DESCRIPTION = 'Показать: Дата поступления в продажу на странице товара.';

const MODULE_CONTENT_PI_DATE_AVAILABLE_TEXT        = 'Дата поступления в продажу: <span class="badge badge-primary badge-pill">%s</span>';