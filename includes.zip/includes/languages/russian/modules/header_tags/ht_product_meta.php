<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2016 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_PRODUCT_META_TITLE', 'Продукт Meta SEO');
  define('MODULE_HEADER_TAGS_PRODUCT_META_DESCRIPTION', 'Добавить элементы META CEO для продуктов, в шапку страниц продуктов');

