cfg_ps_pdt_identity_token_title = PDT Identity Token
cfg_ps_pdt_identity_token_desc = Ваша дата передачи сведений о платеже (PDT) соответствует Token. Это отображается на странице платежных настроек веб-сайта PayPal и используется для проверки транзакций.
