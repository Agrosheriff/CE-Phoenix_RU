<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2018 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_MANUFACTURER_INFO_TITLE', 'Информация о производителе');
  define('MODULE_BOXES_MANUFACTURER_INFO_DESCRIPTION', 'Показывать информацию о производителе на странице тоовара');
  define('MODULE_BOXES_MANUFACTURER_INFO_BOX_TITLE', 'Производитель товара');
  define('MODULE_BOXES_MANUFACTURER_INFO_BOX_HOMEPAGE', 'Сайт производителя %s');
  define('MODULE_BOXES_MANUFACTURER_INFO_BOX_OTHER_PRODUCTS', 'Другие товары производителя');
