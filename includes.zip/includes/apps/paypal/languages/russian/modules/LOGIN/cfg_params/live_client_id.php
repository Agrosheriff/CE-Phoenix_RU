cfg_login_live_client_id_title = Реальный ID клиента.
cfg_login_live_client_id_desc = ID клиента. Реальные учетные данные PayPal для приложения REST.
