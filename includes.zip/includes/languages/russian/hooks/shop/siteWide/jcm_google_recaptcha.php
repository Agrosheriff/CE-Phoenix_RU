<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
  Updated for Phoniex Hooks V1.0 by JcMagie 12-01-2020. Ru translated Fred.
*/

//google
define('MODULE_CONTENT_RECAPTCHA_ERROR','Извините, вы должны доказать, что вы человек, а не робот. Заполните пожалуйста Google Captcha');
define('MODULE_CONTENT_RECAPTCHA_SITEKEY','--- Вставить публичный ключ');
define('MODULE_CONTENT_RECAPTCHA_SECRETKEY','--- вставить секретный ключ');