<?php
/*
$Id$
osCommerce, Open Source E-Commerce Solutions
http://www.oscommerce.com
Copyright (c) 2020 osCommerce
Translation to RU from Fredi. Updated 7/01/2020
Released under the GNU General Public License
*/

define('MODULE_CONTENT_NAVBAR_TITLE', 'Панель навигации');
define('MODULE_CONTENT_NAVBAR_DESCRIPTION', 'Показывать панель навигации на вашем сайте.<div class="secWarning">Этот модуль имеет ряд дополнительных модулей, которые также должны быть установлены.<br><br>Admin > Modules > Navbar Modules</div>');

