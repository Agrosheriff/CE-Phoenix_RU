<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_PARTNER_NEWS_TITLE', 'Новости партнеров');
define('MODULE_ADMIN_DASHBOARD_PARTNER_NEWS_DESCRIPTION', 'Показать последние osCommerce новости партнеров');
define('MODULE_ADMIN_DASHBOARD_PARTNER_NEWS_MORE_TITLE', 'Смотри более сервисы партнеров');
define('MODULE_ADMIN_DASHBOARD_PARTNER_NEWS_ERROR_JSON_DECODE', 'PHP json_decode() требуется обязательная функция.');
?>
