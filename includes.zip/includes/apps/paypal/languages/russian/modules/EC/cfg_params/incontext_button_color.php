cfg_ec_incontext_button_color_title = Checkout Button Color
cfg_ec_incontext_button_color_desc = Цвет кнопки PayPal.

cfg_ec_incontext_button_color_gold = Золотая
cfg_ec_incontext_button_color_blue = Синяя
cfg_ec_incontext_button_color_silver = Серебро
