cfg_login_sandbox_client_id_title = Проверка Client ID
cfg_login_sandbox_client_id_desc = Идентификатор клиента для проверки учетных данных приложения REST приложения PayPal.
