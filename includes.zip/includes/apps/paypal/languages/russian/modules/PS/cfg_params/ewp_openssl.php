cfg_ps_ewp_openssl_title = OpenSSL расположение
cfg_ps_ewp_openssl_desc = Расположение и имя файла в двоичном файле openssl.