cfg_login_live_secret_title = Live Secret
cfg_login_live_secret_desc = Секретные учетные данные PayPal приложения REST. Живые учетные данные.
