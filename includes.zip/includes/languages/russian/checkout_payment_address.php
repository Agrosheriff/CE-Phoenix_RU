<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2019 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Оформление заказа');
define('NAVBAR_TITLE_2', 'Изменить адрес плательщика');

define('HEADING_TITLE', 'Выбрать способ оплаты');

define('TABLE_HEADING_PAYMENT_ADDRESS', 'Адрес покупателя');

define('TABLE_HEADING_ADDRESS_BOOK_ENTRIES', 'Выберите нужный сохраненный адрес');

define('TABLE_HEADING_NEW_PAYMENT_ADDRESS', 'Сохраните новый адрес');
define('TEXT_CREATE_NEW_PAYMENT_ADDRESS', 'Используйте следующую форму, чтобы создать и сохранить новый адрес для использования в этом заказе.');

define('BUTTON_CONTINUE_CHECKOUT_PROCEDURE', 'Обновить мой адрес');
