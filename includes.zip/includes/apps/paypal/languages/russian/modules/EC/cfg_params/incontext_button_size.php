cfg_ec_incontext_button_size_title = Размер кнопки
cfg_ec_incontext_button_size_desc = Размер кнопки PayPal.

cfg_ec_incontext_button_size_tiny = Микро
cfg_ec_incontext_button_size_small = Малая
cfg_ec_incontext_button_size_medium = Средняя
