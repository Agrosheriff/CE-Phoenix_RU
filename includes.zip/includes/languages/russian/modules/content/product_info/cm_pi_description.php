<?php
/*
$Id$
osCommerce, Open Source E-Commerce Solutions
http://www.oscommerce.com
Copyright (c) 2020 osCommerce
Translation to RU from Fredi. Updated 7/01/2020
Released under the GNU General Public License
*/

  const MODULE_CONTENT_PI_DESCRIPTION_TITLE       = 'Описание товара';
  const MODULE_CONTENT_PI_DESCRIPTION_DESCRIPTION = 'Показать: Описание товара на странице товара.';
