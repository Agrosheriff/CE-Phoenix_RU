<?php
/*
$Id$
osCommerce, Open Source E-Commerce Solutions
http://www.oscommerce.com
Copyright (c) 2020 osCommerce
Translation to RU from Fredi. Updated 7/01/2020
Released under the GNU General Public License
*/

const MODULE_CONTENT_PRODUCT_INFO_REVIEWS_TITLE       = 'Отзывы о товаре';
const MODULE_CONTENT_PRODUCT_INFO_REVIEWS_DESCRIPTION = 'Показывать блок отзывов в карточке товара.';

const MODULE_CONTENT_PRODUCT_INFO_REVIEWS_TEXT_TITLE = 'Что говорят наши покупатели...';
const MODULE_CONTENT_PRODUCT_INFO_REVIEWS_TEXT_RATED  = 'Оценка %1$s от <cite title="%2$s">%2$s</cite>';