<?php
/*
$Id$
osCommerce, Open Source E-Commerce Solutions
http://www.oscommerce.com
Copyright (c) 2020 osCommerce
Translation to RU from Fredi. Updated 7/01/2020
Released under the GNU General Public License
*/

define('MODULE_CONTENT_HEADER_BUTTONS_TITLE', 'Кнопки');
define('MODULE_CONTENT_HEADER_BUTTONS_DESCRIPTION', 'Добавить кнопки Логин/Оформить в заголовок сайта.');

define('MODULE_CONTENT_HEADER_BUTTONS_TITLE_CART_CONTENTS', 'Моя корзина');
define('MODULE_CONTENT_HEADER_BUTTONS_TITLE_CHECKOUT', 'Оформить заказ');
define('MODULE_CONTENT_HEADER_BUTTONS_TITLE_LOGOFF', 'Выход');  
define('MODULE_CONTENT_HEADER_BUTTONS_TITLE_MY_ACCOUNT', 'Мой Кабинет');

