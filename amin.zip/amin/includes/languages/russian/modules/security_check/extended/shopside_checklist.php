<?php
/*
  Copyright (c) 2019, G Burton
  All rights reserved. 
  Translation to RU from Fredi. Updated 7/01/2020
*/

define('MODULE_SECURITY_CHECK_EXTENDED_SHOPSIDE_CHECKLIST_TITLE', 'Контрольный список пользователей');
define('MODULE_SECURITY_CHECK_EXTENDED_SHOPSIDE_CHECKLIST_MESSAGE', 'Смотрите наш онлайн <a target="_blank" rel="noopener" href="https://github.com/gburton/Responsive-osCommerce#user-checklist"><u>Контрольный список пользователей</u></a> для основного списка задач, которые вы должны выполнить.');

