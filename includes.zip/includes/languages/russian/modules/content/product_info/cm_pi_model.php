<?php
/*
$Id$
osCommerce, Open Source E-Commerce Solutions
http://www.oscommerce.com
Copyright (c) 2020 osCommerce
Translation to RU from Fredi. Updated 7/01/2020
Released under the GNU General Public License
*/

const MODULE_CONTENT_PI_MODEL_TITLE         = 'Модель';
const MODULE_CONTENT_PI_MODEL_DESCRIPTION   = 'Показать модель товара на стр.';

const MODULE_CONTENT_PI_MODEL_DISPLAY_MODEL = 'Модель:<span class="badge badge-primary badge-pill">%s</span>';
