table_heading_action = Действие
table_heading_ip = IP
table_heading_customer = Клиент
table_heading_date = Дата

guest = Гость

no_entries = Записей журнала не найдено.

listing_number_of_log_entries = Показать <b>%d</b> до <b>%d</b> (от <b>%d</b> входов)

dialog_delete_title = Удалить все логи?
dialog_delete_body = Действительно удалить?

table_heading_entries_request = Запрос
table_heading_entries_response = Отклик

alert_delete_success = Записи в журнале были успешно удалены.
