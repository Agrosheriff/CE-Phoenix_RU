<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2019 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

  define('MODULES_ADMIN_MENU_PAYPAL_HEADING', '<i class="fab fa-paypal fa-fw mr-1"></i>Оплата PayPal');

  define('MODULES_ADMIN_MENU_PAYPAL_BALANCE', 'Баланс');
  define('MODULES_ADMIN_MENU_PAYPAL_CONFIGURE', 'Конфигурация');
  define('MODULES_ADMIN_MENU_PAYPAL_LOG', 'Журнал');
  define('MODULES_ADMIN_MENU_PAYPAL_MANAGE_CREDENTIALS', 'Полномочия');
  define('MODULES_ADMIN_MENU_PAYPAL_START', 'Старт');
  