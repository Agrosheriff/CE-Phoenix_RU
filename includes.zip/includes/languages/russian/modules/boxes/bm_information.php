<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2018 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

  define('MODULE_BOXES_INFORMATION_TITLE', 'Информация');
  define('MODULE_BOXES_INFORMATION_DESCRIPTION', 'Показать линки на страницы');
   define('MODULE_BOXES_INFORMATION_BOX_TITLE', 'Информация');
  
    const MODULE_BOXES_INFORMATION_BOX_DATA = array(
    'privacy.php' => 'Безопасность',
    'conditions.php' => 'Условия использования',
    'shipping.php' => 'Доставка',
    'contact_us.php' => 'Контакты'
  );
  
