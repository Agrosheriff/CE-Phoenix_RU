cfg_login_content_width_title = Ширина содержимого
cfg_login_content_width_desc = Должно ли содержимое отображаться в контейнере с полной или половинной шириной?

cfg_login_content_width_half = Половина
cfg_login_content_width_full = Полностью
