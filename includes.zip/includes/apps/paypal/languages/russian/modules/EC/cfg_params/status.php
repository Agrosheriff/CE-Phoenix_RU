cfg_ec_status_title = Статус
cfg_ec_status_desc = Set this to Live to start accepting payments or to Sandbox to perform test orders.

cfg_ec_status_live = Рабочий
cfg_ec_status_sandbox = Sandbox
cfg_ec_status_disabled = Отключено
