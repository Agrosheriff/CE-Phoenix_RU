cfg_dp_status_title = Статус
cfg_dp_status_desc = Установите на Live, чтобы начать принимать платежи или на тестовый режим для выполнения тестовых заказов.

cfg_dp_status_live = Live (Живая оплата)
cfg_dp_status_sandbox = Sandbox (Тест)
cfg_dp_status_disabled = Отключено
