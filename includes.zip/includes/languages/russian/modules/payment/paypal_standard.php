<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

// language definitions have been moved to:
// catalog/includes/apps/paypal/languages/russian/modules/PS/PS.php
?>
