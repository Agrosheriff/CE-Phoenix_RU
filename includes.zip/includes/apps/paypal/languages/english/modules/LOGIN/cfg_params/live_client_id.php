cfg_login_live_client_id_title = Live Client ID
cfg_login_live_client_id_desc = The Client ID of the PayPal REST App Live Credentials.
