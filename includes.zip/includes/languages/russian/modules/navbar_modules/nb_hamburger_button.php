<?php
/*
$Id$
osCommerce, Open Source E-Commerce Solutions
http://www.oscommerce.com
Copyright (c) 2020 osCommerce
Translation to RU from Fredi. Updated 7/01/2020
Released under the GNU General Public License
*/

define('MODULE_NAVBAR_HAMBURGER_BUTTON_TITLE', 'Кнопка Гамбургер');
define('MODULE_NAVBAR_HAMBURGER_BUTTON_DESCRIPTION', 'Показать Кнопку Гамбургер в Навигационной панели.  <div class="secWarning">Это специальная кнопка, которая показывает, когда экран маленький. <br> <br> Она открывает и закрывает меню Main навигационной панели. Вы <b> ДОЛЖНЫ </ b> установить это.</div>');

define('MODULE_NAVBAR_HAMBURGER_BUTTON_PUBLIC_SCREENREADER_TEXT', 'Переключатель навигации');
define('MODULE_NAVBAR_HAMBURGER_BUTTON_PUBLIC_BUTTON_TEXT', '<span class="navbar-toggler-icon"></span>');

