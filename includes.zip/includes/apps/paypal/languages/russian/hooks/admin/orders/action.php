ms_success_getTransactionDetails = Информация о транзакции PayPal успешно восстановлена.
ms_error_getTransactionDetails = При получении данных транзакции PayPal возникла проблема. Дополнительную информацию см. В журнале приложений PayPal App.

ms_success_doCapture = Транзакция PayPal успешно зарегистрирована.
ms_error_doCapture = Возникла проблема при захвате транзакции PayPal. Дополнительную информацию см. В журнале приложений PayPal App.

ms_success_doVoid = Транзакция PayPal успешно отменена.
ms_error_doVoid = Возникла проблема при отмене транзакции PayPal. Дополнительную информацию см. В журнале приложений PayPal App.

ms_success_refundTransaction = Транзакция PayPal была успешно возвращена (:refund_amount).
ms_error_refundTransaction = Возникла проблема при возврате транзакции PayPal (:refund_amount). Дополнительную информацию см. В журнале приложений PayPal App.
