<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_MAILCHIMP_360_TITLE', 'MailChimp E-Commerce 360');
  define('MODULE_HEADER_TAGS_MAILCHIMP_360_DESCRIPTION', '<img src="images/icon_popup.gif" border="0">&nbsp;<a href="http://eepurl.com/bxza1" target="_blank" style="text-decoration: underline; font-weight: bold;">Посетить сайт MailChimp</a>&nbsp;<a href="javascript:toggleDivBlock(\'mailchimpInfo\');">(info)</a><span id="mailchimpInfo" style="display: none;"><br /><i>Использование выше ссылку, чтобы зарегистрироваться на MailChimp предоставляет интернет-магазина небольшой финансовой бонус для клиента со ссылкой.</i></span><br /><br />The MailChimp E-Commerce 360 module measures the ROI of your MailChimp e-mail campaigns');
?>
