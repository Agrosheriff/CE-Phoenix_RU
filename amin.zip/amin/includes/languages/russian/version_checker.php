<?php
/*
  $Id: version checker, v 1.3
  Originally Created by: Jack_mcs - http://www.oscommerce-solution.com
  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce
  Portions Copyright 2009 oscommerce-solution.com

  Released under the GNU General Public License
*/
define('ERROR_NO_VERSION_MATCH_FOUND', 9999);

define('TEXT_VERSION_CHECK_UPDATES', 'Проверить для обновления');
define('TEXT_VERSION_CHECK_UPDATES_UNRELEASED', 'Проверить нереализованные обновления');
define('TEXT_VERSION_LATEST', '%s это последняя версия');
define('TEXT_VERSION_NO_MATCH_FOUND', 'Нет обновлений.');
define('TEXT_VERSION_FOUND_UPDATE', 'Это %s есть');
define('TEXT_IS', ' %s обновлено');
define('TEXT_ARE', 'в процессе %s обновления');

?>