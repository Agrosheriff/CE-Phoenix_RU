<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2019 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_SPECIALS_TITLE', 'Скидки');
  define('MODULE_BOXES_SPECIALS_DESCRIPTION', 'Показывать товары со скидками');
  
  define('MODULE_BOXES_SPECIALS_BOX_TITLE', '<a href="%s">Специальные предложения</a>');
