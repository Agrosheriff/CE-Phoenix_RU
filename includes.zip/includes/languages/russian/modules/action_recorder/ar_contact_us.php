<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_ACTION_RECORDER_CONTACT_US_TITLE', 'Контакты');
  define('MODULE_ACTION_RECORDER_CONTACT_US_DESCRIPTION', 'Запись о  выполнении действия - Contact Us feature.');
?>
