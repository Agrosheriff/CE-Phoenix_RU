cfg_ec_status_title = Status
cfg_ec_status_desc = Set this to Live to start accepting payments or to Sandbox to perform test orders.

cfg_ec_status_live = Live
cfg_ec_status_sandbox = Sandbox
cfg_ec_status_disabled = Disabled
