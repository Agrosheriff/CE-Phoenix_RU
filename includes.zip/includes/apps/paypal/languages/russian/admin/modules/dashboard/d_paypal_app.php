module_admin_dashboard_title = PayPal App
module_admin_dashboard_description = Модуль панели приложений PayPal App для отображения баланса PayPal и уведомлений об обновлении версии приложения.

heading_live_account = PayPal Live: :акаунт
heading_sandbox_account = PayPal Sandbox: :акаунт

button_app_get_started = Начало работы с приложением PayPal
button_view_update = Посмотреть обновления

update_available_body = <p>Есть обновления для PayPal App!</p>
<p><small>:button_view_update</small></p>
