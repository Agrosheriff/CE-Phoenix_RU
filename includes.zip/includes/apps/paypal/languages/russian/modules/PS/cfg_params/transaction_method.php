cfg_ps_transaction_method_title = Метод оплаты
cfg_ps_transaction_method_desc = Установите это для продажи, чтобы немедленно захватить средства для каждого сделанного заказа.

cfg_ps_transaction_method_authorize = Authorize
cfg_ps_transaction_method_sale = Sale
