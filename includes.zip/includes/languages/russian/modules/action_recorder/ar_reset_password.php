<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2012 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_ACTION_RECORDER_RESET_PASSWORD_TITLE', 'Смена пароля посетителя');
  define('MODULE_ACTION_RECORDER_RESET_PASSWORD_DESCRIPTION', 'Запись о смене пароля пользователя.');
?>
