<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2019 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Страница оформления Заказа');
define('NAVBAR_TITLE_2', 'Изменить адрес доставки');

define('HEADING_TITLE', 'Информация о доставке заказа');

define('TABLE_HEADING_SHIPPING_ADDRESS', 'Выберите адрес для доставки');

define('TABLE_HEADING_ADDRESS_BOOK_ENTRIES', 'Выберите адрес в адресной книге');

define('TABLE_HEADING_NEW_SHIPPING_ADDRESS', 'Добавить новый адрес'); 
define('TEXT_CREATE_NEW_SHIPPING_ADDRESS', 'Заполните пожалуйста эту форму, чтобы создать новый адрес для доставки вашего заказа.');

define('BUTTON_CONTINUE_CHECKOUT_PROCEDURE', 'Обновить мой адрес для доставки');
