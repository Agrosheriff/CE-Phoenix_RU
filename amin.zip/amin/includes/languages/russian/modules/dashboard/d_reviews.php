<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_REVIEWS_TITLE', 'Отзывы');
define('MODULE_ADMIN_DASHBOARD_REVIEWS_DESCRIPTION', 'Показать последние отзывы');
define('MODULE_ADMIN_DASHBOARD_REVIEWS_REVIEWER', 'Кем отзыв написан:');
define('MODULE_ADMIN_DASHBOARD_REVIEWS_DATE', 'Дата');
define('MODULE_ADMIN_DASHBOARD_REVIEWS_RATING', 'Рейтинг');
define('MODULE_ADMIN_DASHBOARD_REVIEWS_REVIEW_STATUS', 'Статус');
define('MODULE_ADMIN_DASHBOARD_TOTAL_REVENUE_STEP', 'Шаг доходов');
?>
