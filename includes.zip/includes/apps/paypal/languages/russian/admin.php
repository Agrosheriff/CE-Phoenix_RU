app_link_info = Инфо/помощь
app_link_privacy = Конфиденциальность

button_retrieve_live_credentials = Получать живую оплату
button_retrieve_sandbox_credentials = Получить тестовый режим Sandbox

button_back = Назад
button_cancel = Отмена
button_delete = Удалить
button_dialog_delete = Удалить &hellip;
button_install = Установить
button_install_title = Установить :title
button_save = Сохранить
button_uninstall = Деинсталлировать
button_dialog_uninstall = Деинсталлировать &hellip;
button_view = Посмотреть
button_view_update = Посмотреть обновления

update_available_body = <p>Обновление доступно для этого приложения!</p>
<p><small>:button_view_update</small></p>
