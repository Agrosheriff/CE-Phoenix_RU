<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2018 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

  const MODULE_CONTENT_IN_TITLE_TITLE        = 'Заголовок страницы';
  const MODULE_CONTENT_IN_TITLE_DESCRIPTION  = 'Показать название категории на отдельных страницах категорий.';
  
  const MODULE_CONTENT_IN_TITLE_PUBLIC_TITLE = '%s';
  