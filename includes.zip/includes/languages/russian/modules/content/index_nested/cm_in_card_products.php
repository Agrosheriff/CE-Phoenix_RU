<?php
/*
$Id$
osCommerce, Open Source E-Commerce Solutions
http://www.oscommerce.com
Copyright (c) 2020 osCommerce
Translation to RU from Fredi. Updated 7/01/2020
Released under the GNU General Public License
*/

define('MODULE_CONTENT_IN_CARD_PRODUCTS_TITLE', 'Новые товары');
define('MODULE_CONTENT_IN_CARD_PRODUCTS_DESCRIPTION', 'Показать "Новые товары" на Index page.');

define('MODULE_CONTENT_IN_CARD_PRODUCTS_HEADING', 'Новинки');

