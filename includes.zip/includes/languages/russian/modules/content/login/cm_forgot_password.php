<?php
/*
$Id$
osCommerce, Open Source E-Commerce Solutions
http://www.oscommerce.com
Copyright (c) 2020 osCommerce
Translation to RU from Fredi. Updated 7/01/2020
Released under the GNU General Public License
*/

define('MODULE_CONTENT_FORGOT_PASSWORD_TITLE', 'Забыли пароль');
define('MODULE_CONTENT_FORGOT_PASSWORD_DESCRIPTION', 'Показать ссылку, чтобы позволить клиенту сбросить пароль на странице входа');

define('MODULE_CONTENT_FORGOT_PASSWORD_INTRO_TEXT', 'Забыли ваш пароль?  Нет проблем!');
define('MODULE_CONTENT_FORGOT_PASSWORD_BUTTON_TEXT', 'Обновить ваш пароль');

