<?php
/*
  $Id:ht_record_order_shipping_module.php$

  $Path:catalog\includes\languages\english\modules\header_tags\$

 osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2017 osCommerce

  Released under the GNU General Public License

  20191007 Denkster added Order_Editor_v1.2.5_for_2.3.4_BS
*/

  define('MODULE_HEADER_TAGS_ORDER_SHIPPING_TITLE', 'Запись способов доставки для заказов');
  define('MODULE_HEADER_TAGS_ORDER_SHIPPING_DESCRIPTION', 'Когда заказы созданы, запишите способ доставки в заказе.');

