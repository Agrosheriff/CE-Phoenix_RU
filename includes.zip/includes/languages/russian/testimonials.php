<?php
/*
$Id$
osCommerce, Open Source E-Commerce Solutions
http://www.oscommerce.com
Copyright (c) 2020 osCommerce
Translation to RU from Fredi. Updated 7/01/2020
Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Рекомендации');
define('HEADING_TITLE', 'Рекомендации заказчиков и специалистов');

define('TEXT_NO_TESTIMONIALS', 'Нет рекомендаций для просмотра.');

define('TEXT_DISPLAY_NUMBER_OF_TESTIMONIALS', 'Посмотреть <b>%s</b> до <b>%s</b> (от <b>%s</b> Рекомендации)');
