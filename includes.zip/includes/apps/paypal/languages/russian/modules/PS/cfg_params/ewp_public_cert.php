cfg_ps_ewp_public_cert_title = Ваш Public Certificate
cfg_ps_ewp_public_cert_desc = Местоположение и имя вашего открытого сертификата для шифрования параметров. (* .pem)
