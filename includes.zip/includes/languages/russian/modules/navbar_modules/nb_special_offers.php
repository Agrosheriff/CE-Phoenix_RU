<?php
/*
$Id$
osCommerce, Open Source E-Commerce Solutions
http://www.oscommerce.com
Copyright (c) 2020 osCommerce
Translation to RU from Fredi. Updated 7/01/2020
Released under the GNU General Public License
*/

  define('MODULE_NAVBAR_SPECIAL_OFFERS_TITLE', 'Специальные предложения');
  define('MODULE_NAVBAR_SPECIAL_OFFERS_DESCRIPTION', 'Показать ссылку на Специальные предложения в Панели навигации.');

  define('MODULE_NAVBAR_SPECIAL_OFFERS_PUBLIC_TEXT', '<i title="Специальные предложения" class="fas fa-fire"></i><span class="d-inline d-sm-none d-md-inline"> Специальные предложения</span>');

