<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2019 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Проверка прав доступа к директориям');

define('TABLE_HEADING_DIRECTORIES', 'Директория');
define('TABLE_HEADING_WRITABLE', 'Доступна на записть');
define('TABLE_HEADING_RECOMMENDED', 'Рекомендовано');

define('TEXT_DIRECTORY', 'Директории:');
?>
