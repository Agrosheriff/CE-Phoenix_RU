<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2019 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Вход');
define('NAVBAR_TITLE_2', 'Смена пароля');

define('HEADING_TITLE', 'Смена пароля');

define('TEXT_MAIN', 'Введите новый пароль.');

define('TEXT_NO_RESET_LINK_FOUND', 'Ошибка: Ссылка на смену пароля не найдена в нашей базе, попробуйте ещё раз запросить смену пароля.');
define('TEXT_NO_EMAIL_ADDRESS_FOUND', 'Ошибка: Указанный емейл адрес не найден в нашей базе. Попробуйте ещё раз.');

define('SUCCESS_PASSWORD_RESET', 'Ваш пароль успешно изменён. Пожалуйста войдите в свой Кабинет с новым паролем.');
?>