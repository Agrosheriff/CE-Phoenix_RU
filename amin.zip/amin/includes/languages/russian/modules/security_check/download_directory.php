<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

define('WARNING_DOWNLOAD_DIRECTORY_NON_EXISTENT', 'Каталога для виртуальных (загружаемых) товаров не существует: ' . DIR_FS_DOWNLOAD . '. Загружаемые товары не будут работать пока эта директория не создана.');
?>
