section_general = Главная
section_more = +

dialog_uninstall_title = Деинсталлировать модуль?
dialog_uninstall_body = Вы уверены, что хотите удалить этот модуль?

alert_module_install_success = Модуль успешно установлен.
alert_module_uninstall_success = Модуль успешно деинсталлирован.
alert_cfg_saved_success = Параметры конфигурации были успешно сохранены.
