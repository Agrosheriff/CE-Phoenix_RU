<?php
/*
$Id$
osCommerce, Open Source E-Commerce Solutions
http://www.oscommerce.com
Copyright (c) 2020 osCommerce
Translation to RU from Fredi. Updated 7/01/2020
Released under the GNU General Public License
*/

define('MODULE_CONTENT_FOOTER_CONTACT_US_TITLE', 'Контакты');
define('MODULE_CONTENT_FOOTER_CONTACT_US_DESCRIPTION', 'Добавить блок Контанты в подвал сайта');

define('MODULE_CONTENT_FOOTER_CONTACT_US_HEADING_TITLE', 'Как с нами связаться');
define('MODULE_CONTENT_FOOTER_CONTACT_US_EMAIL_LINK', 'Контакты');

define('MODULE_CONTENT_FOOTER_CONTACT_US_PHONE', '<i class="fas fa-phone fa-fw mr-1" title="Телефон"></i>');
define('MODULE_CONTENT_FOOTER_CONTACT_US_EMAIL', '<i class="fas fa-at fa-fw mr-1" title="Email"></i>');

