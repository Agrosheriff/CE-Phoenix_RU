<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce
  Translation to RU from Fredi. Updated 7/01/2020
  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_LATEST_ADDONS_TITLE', 'Последние дополнения Add-Ons');
define('MODULE_ADMIN_DASHBOARD_LATEST_ADDONS_DESCRIPTION', 'Показать последние osCommerce Add-Ons');
define('MODULE_ADMIN_DASHBOARD_LATEST_ADDONS_DATE', 'Дата');
define('MODULE_ADMIN_DASHBOARD_LATEST_ADDONS_FEED_ERROR', 'Не удается подключиться к серверу. Следующая попытка будет выполнена в течение 24 часов.');
define('MODULE_ADMIN_DASHBOARD_LATEST_ADDONS_ICON_SITE', 'Посетить osCommerce Add-Ons Site');
define('MODULE_ADMIN_DASHBOARD_LATEST_ADDONS_ICON_RSS', 'Подписаться на osCommerce Add-Ons RSS Feed');
?>
